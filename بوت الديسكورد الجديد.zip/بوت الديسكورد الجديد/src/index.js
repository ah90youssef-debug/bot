require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const commandHandler = require('./handlers/commandHandler');
const eventHandler = require('./handlers/eventHandler');
const logger = require('./utils/logger');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [
    Partials.Channel,
    Partials.Message,
    Partials.User,
    Partials.GuildMember,
    Partials.Reaction
  ]
});

// Collections
client.commands = new Collection();
client.cooldowns = new Collection();

// Load Handlers
commandHandler(client);
eventHandler(client);

// Error Handling to prevent crashes
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err);
});

// Login
const token = process.env.BOT_TOKEN;
if (!token || token === 'YOUR_BOT_TOKEN_HERE') {
  logger.warn('⚠️ لم يتم وضع BOT_TOKEN داخل ملف .env بعد.');
  logger.info('💡 يمكنك إضافة التوكن في ملف .env وسيعمل البوت مباشرة.');
} else {
  client.login(token).catch(err => {
    logger.error('فشل تسجيل الدخول بالتوكن المدخل:', err.message);
  });
}

module.exports = client;
