module.exports = {
  general: {
    language: 'ar-EG', // Egyptian Arabic default
    adminRoles: [],
    modRoles: []
  },
  welcome: {
    enabled: true,
    channelId: null,
    message: 'منور يا {user} في سيرفر **{server}**! 🎉 أنت العضو رقم **#{count}**، نتمنى لك وقت ممتع معانا يا باشا!',
    sendDm: false,
    dmMessage: 'أهلاً بيك يا {user} في سيرفر {server}! نورتنا وشرفتنا 👑',
    autoRoleId: null,
    imageEnabled: true
  },
  leave: {
    enabled: true,
    channelId: null,
    message: 'مع السلامة يا {user}.. هنشتاقلك في {server} والله 💔'
  },
  logs: {
    enabled: true,
    channelId: null,
    events: {
      memberJoin: true,
      memberLeave: true,
      messageDelete: true,
      messageUpdate: true,
      channelCreate: true,
      channelDelete: true,
      roleCreate: true,
      roleDelete: true,
      memberRoleUpdate: true,
      modActions: true,
      serverUpdate: true
    }
  },
  tickets: {
    enabled: true,
    categoryId: null,
    logChannelId: null,
    supportRoleIds: [],
    counter: 0,
    categories: [
      { id: 'tech', label: 'دعم فني واستفسارات', emoji: '🛠️', description: 'لو عندك مشكلة أو استفسار فني' },
      { id: 'report', label: 'شكاوى وبلاغات', emoji: '🚨', description: 'للإبلاغ عن عضو أو مشكلة إدارية' },
      { id: 'partner', label: 'شراكات وإعلانات', emoji: '🤝', description: 'لطلبات الشراكة والتبادل الإعلاني' },
      { id: 'other', label: 'موضوع تاني', emoji: '💡', description: 'أي حاجة تانية محتاج فيها الإدارة' }
    ]
  },
  antiRaid: {
    enabled: true,
    maxJoinsIn10Sec: 5,
    action: 'kick', // 'kick' or 'timeout' or 'ban'
    alertChannelId: null
  },
  antiNuke: {
    enabled: true,
    maxChannelDeletesPerMin: 3,
    maxRoleDeletesPerMin: 3,
    maxBansPerMin: 3,
    alertChannelId: null,
    whitelist: [] // User IDs exempt from anti-nuke
  },
  levels: {
    enabled: true,
    channelId: null, // null means current channel
    message: 'مبروك يا {user}! وصلت للمستوى **{level}** وعملت شغل عالي يا فنان! 🔥',
    xpMin: 15,
    xpMax: 25,
    cooldownSeconds: 60,
    roleRewards: [] // [{ level: 5, roleId: '...' }]
  },
  economy: {
    enabled: true,
    currencySymbol: '🪙',
    currencyName: 'جنيه كوين',
    dailyMin: 100,
    dailyMax: 300,
    workMin: 50,
    workMax: 150,
    shopItems: [
      { id: 'vip', name: 'رتبة VIP', price: 2500, roleId: null, description: 'رتبة كبار الشخصيات مع مميزات خاصة' },
      { id: 'pro', name: 'رتبة مروقها (Pro)', price: 5000, roleId: null, description: 'رتبة النجوم في السيرفر' }
    ]
  },
  suggestions: {
    enabled: true,
    channelId: null
  },
  moderation: {
    logChannelId: null,
    autoPunishment: {
      enabled: true,
      thresholds: [
        { count: 3, action: 'timeout', durationMs: 3600000, label: 'تايم اوت ساعة' },
        { count: 5, action: 'kick', label: 'طرد من السيرفر' },
        { count: 7, action: 'ban', label: 'حظر نهائي' }
      ]
    }
  },
  serverStats: {
    enabled: false,
    categoryName: '📊 إحصائيات السيرفر',
    membersChannelId: null,
    botsChannelId: null,
    channelsChannelId: null
  }
};
