const fs = require('fs');
const path = require('path');
const defaultSettings = require('./defaultSettings');

const dataDir = path.join(__dirname, '..', '..', 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

class Database {
  constructor() {
    this.guildsFile = path.join(dataDir, 'guilds.json');
    this.usersFile = path.join(dataDir, 'users.json');
    this.ticketsFile = path.join(dataDir, 'tickets.json');
    this.giveawaysFile = path.join(dataDir, 'giveaways.json');
    this.suggestionsFile = path.join(dataDir, 'suggestions.json');

    this.guilds = this._load(this.guildsFile, {});
    this.users = this._load(this.usersFile, {});
    this.tickets = this._load(this.ticketsFile, []);
    this.giveaways = this._load(this.giveawaysFile, []);
    this.suggestions = this._load(this.suggestionsFile, []);

    this._saveScheduled = {};
  }

  _load(filePath, defaultVal) {
    try {
      if (fs.existsSync(filePath)) {
        const raw = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.error(`[DB] Error loading ${filePath}:`, err.message);
    }
    return defaultVal;
  }

  _queueSave(key, filePath, data) {
    if (this._saveScheduled[key]) return;
    this._saveScheduled[key] = setTimeout(() => {
      try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
      } catch (err) {
        console.error(`[DB] Error saving ${key}:`, err.message);
      }
      delete this._saveScheduled[key];
    }, 500);
  }

  // GUILD SETTINGS
  getGuild(guildId) {
    if (!this.guilds[guildId]) {
      this.guilds[guildId] = JSON.parse(JSON.stringify(defaultSettings));
      this._queueSave('guilds', this.guildsFile, this.guilds);
    }
    // Deep merge to ensure all defaults exist even after schema updates
    return this.guilds[guildId];
  }

  updateGuild(guildId, updater) {
    const current = this.getGuild(guildId);
    if (typeof updater === 'function') {
      updater(current);
    } else if (typeof updater === 'object') {
      Object.assign(current, updater);
    }
    this._queueSave('guilds', this.guildsFile, this.guilds);
    return current;
  }

  // USER DATA (XP, Levels, Economy, Warnings)
  getUser(guildId, userId) {
    const key = `${guildId}_${userId}`;
    if (!this.users[key]) {
      this.users[key] = {
        guildId,
        userId,
        xp: 0,
        level: 1,
        lastXpAt: 0,
        wallet: 100, // starting balance
        bank: 0,
        lastDaily: 0,
        lastWork: 0,
        dailyStreak: 0,
        inventory: [],
        warnings: []
      };
      this._queueSave('users', this.usersFile, this.users);
    }
    return this.users[key];
  }

  updateUser(guildId, userId, updater) {
    const user = this.getUser(guildId, userId);
    if (typeof updater === 'function') {
      updater(user);
    } else if (typeof updater === 'object') {
      Object.assign(user, updater);
    }
    this._queueSave('users', this.usersFile, this.users);
    return user;
  }

  getGuildUsers(guildId) {
    const prefix = `${guildId}_`;
    return Object.keys(this.users)
      .filter(k => k.startsWith(prefix))
      .map(k => this.users[k]);
  }

  // TICKETS
  getTickets(guildId) {
    return this.tickets.filter(t => t.guildId === guildId);
  }

  getTicketByChannel(channelId) {
    return this.tickets.find(t => t.channelId === channelId);
  }

  saveTicket(ticket) {
    const idx = this.tickets.findIndex(t => t.id === ticket.id || (t.channelId && t.channelId === ticket.channelId));
    if (idx >= 0) {
      this.tickets[idx] = { ...this.tickets[idx], ...ticket };
    } else {
      this.tickets.push(ticket);
    }
    this._queueSave('tickets', this.ticketsFile, this.tickets);
    return ticket;
  }

  // GIVEAWAYS
  getGiveaways(guildId) {
    if (guildId) return this.giveaways.filter(g => g.guildId === guildId);
    return this.giveaways;
  }

  getGiveaway(messageId) {
    return this.giveaways.find(g => g.messageId === messageId);
  }

  saveGiveaway(giveaway) {
    const idx = this.giveaways.findIndex(g => g.messageId === giveaway.messageId);
    if (idx >= 0) {
      this.giveaways[idx] = { ...this.giveaways[idx], ...giveaway };
    } else {
      this.giveaways.push(giveaway);
    }
    this._queueSave('giveaways', this.giveawaysFile, this.giveaways);
  }

  deleteGiveaway(messageId) {
    this.giveaways = this.giveaways.filter(g => g.messageId !== messageId);
    this._queueSave('giveaways', this.giveawaysFile, this.giveaways);
  }

  // SUGGESTIONS
  getSuggestions(guildId) {
    if (guildId) return this.suggestions.filter(s => s.guildId === guildId);
    return this.suggestions;
  }

  getSuggestion(messageId) {
    return this.suggestions.find(s => s.messageId === messageId);
  }

  saveSuggestion(suggestion) {
    const idx = this.suggestions.findIndex(s => s.messageId === suggestion.messageId);
    if (idx >= 0) {
      this.suggestions[idx] = { ...this.suggestions[idx], ...suggestion };
    } else {
      this.suggestions.push(suggestion);
    }
    this._queueSave('suggestions', this.suggestionsFile, this.suggestions);
  }
}

module.exports = new Database();
