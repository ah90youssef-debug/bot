require('dotenv').config();
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const logger = require('./utils/logger');

const token = process.env.BOT_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

if (!token || token === 'YOUR_BOT_TOKEN_HERE') {
  logger.error('برجاء كتابة توكن البوت BOT_TOKEN داخل ملف .env قبل تشغيل deploy!');
  process.exit(1);
}

if (!clientId || clientId === 'YOUR_CLIENT_ID_HERE') {
  logger.error('برجاء كتابة CLIENT_ID داخل ملف .env قبل تشغيل deploy!');
  process.exit(1);
}

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(commandsPath);

for (const folder of commandFolders) {
  const folderPath = path.join(commandsPath, folder);
  if (!fs.statSync(folderPath).isDirectory()) continue;

  const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
  for (const file of commandFiles) {
    const filePath = path.join(folderPath, file);
    const command = require(filePath);
    if (command && command.data) {
      commands.push(command.data.toJSON());
    }
  }
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    logger.info(`بدأ تحديث ${commands.length} أمر سلاش...`);

    let data;
    if (guildId) {
      // Guild commands (instant update)
      data = await rest.put(
        Routes.applicationGuildCommands(clientId, guildId),
        { body: commands }
      );
      logger.success(`تم تسجيل ${data.length} أمر سلاش في السيرفر المحدد (${guildId}) بنجاح!`);
    } else {
      // Global commands
      data = await rest.put(
        Routes.applicationCommands(clientId),
        { body: commands }
      );
      logger.success(`تم تسجيل ${data.length} أمر سلاش بشكل عام (Global) بنجاح!`);
    }
  } catch (error) {
    logger.error('فشل في تسجيل أوامر السلاش:', error);
  }
})();
