const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('دليل أوامر البوت وقائمة المساعدة الشاملة (Help Menu)'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`👑 دليل أوامر بوت: ${interaction.client.user.username}`)
      .setDescription(
        `أهلاً بيك يا **${interaction.user.username}** في دليل المساعدة الشامل!\n` +
        `البوت ده متكامل 100% لإدارة وحماية وتنشيط السيرفر باللهجة المصرية والعربية الفصحى بأحدث تقنيات Discord.js v14.\n\n` +
        `⚙️ **لوحة التحكم والإعدادات الداخلية:**\n` +
        `> \`/settings view\`: عرض لوحة تحكم وإعدادات السيرفر كاملة.\n` +
        `> \`/settings toggle\`: تفعيل أو تعطيل أي نظام بضغطة زر.\n` +
        `> \`/settings logs\`: تعيين رومات اللوجات والعقوبات.\n\n` +
        `🛡️ **الإدارة والرقابة (Moderation):**\n` +
        `> \`/ban\`, \`/unban\`, \`/kick\`, \`/timeout\`, \`/untimeout\`\n` +
        `> \`/warn\`, \`/unwarn\`, \`/warnings\`, \`/clear\`\n\n` +
        `🎫 **نظام التذاكر (Tickets):**\n` +
        `> \`/ticket panel\`: إرسال لوحة فتح التذاكر التفاعلية بأزرار.\n` +
        `> \`/ticket add\`, \`/ticket remove\`, \`/ticket settings\`\n\n` +
        `🔒 **الحماية والأمان (Anti-Nuke & Anti-Raid):**\n` +
        `> \`/antinuke status\`: فحص وضع الحماية والقائمة البيضاء.\n` +
        `> \`/antinuke toggle\`, \`/antinuke whitelist\`, \`/antinuke channel\`\n\n` +
        `👋 **الترحيب والمغادرة (Welcome & Leave):**\n` +
        `> \`/welcome channel\`, \`/welcome leavechannel\`, \`/welcome autorole\`, \`/welcome test\`\n\n` +
        `🏆 **المستويات والتفاعل (Levels & XP):**\n` +
        `> \`/rank\`: عرض بطاقة المستوى وشريط التقدم.\n` +
        `> \`/leaderboard\`: قائمة المتصدرين في السيرفر.\n\n` +
        `🪙 **الاقتصاد والكوينز (Economy):**\n` +
        `> \`/balance\`, \`/daily\`, \`/work\`, \`/transfer\`, \`/shop\`, \`/buy\`, \`/ecotop\`\n\n` +
        `🎉 **المجتمع والفعاليات (Community):**\n` +
        `> \`/giveaway start\`, \`/giveaway reroll\`, \`/giveaway end\`\n` +
        `> \`/poll\`, \`/suggest\`, \`/announce\`, \`/quiz\`\n\n` +
        `ℹ️ **المعلومات وإحصائيات السيرفر (Info & Stats):**\n` +
        `> \`/serverinfo\`, \`/userinfo\`, \`/avatar\`, \`/botinfo\`, \`/profile\`, \`/stats setup\`\n`
      )
      .setThumbnail(interaction.client.user.displayAvatarURL())
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
