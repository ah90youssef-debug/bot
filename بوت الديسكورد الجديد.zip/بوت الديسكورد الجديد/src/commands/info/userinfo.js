const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('عرض معلومات شاملة عن حساب عضو (User Info)')
    .addUserOption(opt =>
      opt.setName('user')
        .setDescription('العضو المراد عرض معلوماته (اختياري)')
        .setRequired(false)),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);

    const roles = member ? member.roles.cache.filter(r => r.id !== interaction.guild.id).sort((a, b) => b.position - a.position) : null;
    const rolesList = roles && roles.size > 0 ? roles.map(r => `${r}`).slice(0, 15).join(', ') : 'بدون رتب';

    const embed = new EmbedBuilder()
      .setColor(member?.displayHexColor || config.embedColor)
      .setTitle(`👤 بطاقة بيانات: ${targetUser.tag}`)
      .setThumbnail(targetUser.displayAvatarURL({ size: 512 }))
      .addFields(
        { name: 'الاسم الكامل', value: `${targetUser.tag} (<@${targetUser.id}>)`, inline: true },
        { name: '🆔 الآيدي (User ID)', value: `\`${targetUser.id}\``, inline: true },
        { name: '🤖 نوع الحساب', value: targetUser.bot ? 'بوت (Bot)' : 'حساب بشري', inline: true },

        { name: '📅 تاريخ إنشاء الحساب', value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:D>\n(<t:${Math.floor(targetUser.createdTimestamp / 1000)}:R>)`, inline: true },
        { name: '📥 تاريخ الانضمام للسيرفر', value: member?.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>\n(<t:${Math.floor(member.joinedTimestamp / 1000)}:R>)` : 'غير متوفر', inline: true },
        { name: '👑 أعلى رتبة', value: member?.roles.highest ? `${member.roles.highest}` : 'لا يوجد', inline: true },

        { name: `🛡️ رتب العضو (${roles ? roles.size : 0})`, value: rolesList, inline: false }
      )
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
