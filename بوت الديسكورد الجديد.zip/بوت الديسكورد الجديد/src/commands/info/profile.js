const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('عرض ملفك الشخصي الشامل (المستوى، الكوينز، التحذيرات، الرتب) (Profile)')
    .addUserOption(opt =>
      opt.setName('user')
        .setDescription('العضو المراد استعراض بروفايله (اختياري)')
        .setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const guildId = interaction.guild.id;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    const userData = db.getUser(guildId, target.id);
    const settings = db.getGuild(guildId);
    const symbol = settings.economy?.currencySymbol || '🪙';

    const warningsCount = userData.warnings ? userData.warnings.length : 0;
    const totalCoins = (userData.wallet || 0) + (userData.bank || 0);

    const embed = new EmbedBuilder()
      .setColor(member?.displayHexColor || config.embedColor)
      .setTitle(`🌟 البروفايل الشامل: ${target.tag}`)
      .setThumbnail(target.displayAvatarURL({ size: 512 }))
      .addFields(
        { name: '🎖️ المستوى والخبرة', value: `> المستوى: **${userData.level}**\n> نقاط الخبرة: **${userData.xp} XP**`, inline: true },
        { name: '💰 الاقتصاد والكوينز', value: `> الكاش: **${(userData.wallet || 0).toLocaleString()} ${symbol}**\n> البنك: **${(userData.bank || 0).toLocaleString()} ${symbol}**\n> الإجمالي: **${totalCoins.toLocaleString()}**`, inline: true },
        { name: '⚠️ سجل الانضباط', value: `> التحذيرات: **${warningsCount}** تحذير\n> الحالة: ${warningsCount === 0 ? '🟢 عضو مثالي' : '🟡 لديه مخالفات'}`, inline: true },

        { name: '👑 الرتبة الأساسية', value: member?.roles.highest ? `${member.roles.highest}` : 'بدون رتبة', inline: true },
        { name: '📅 تاريخ الانضمام', value: member?.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'غير متوفر', inline: true },
        { name: '🔥 التفاعل اليومي', value: `> Streak: **${userData.dailyStreak || 0} يوم** متتالي`, inline: true }
      )
      .setFooter({ text: 'سيد المعلمين | بروفايل العضو' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
