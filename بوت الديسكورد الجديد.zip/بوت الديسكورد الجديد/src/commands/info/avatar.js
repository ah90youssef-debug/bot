const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('عرض وتحميل الصورة الشخصية لعضو أو صورة السيرفر (Avatar)')
    .addUserOption(opt =>
      opt.setName('user')
        .setDescription('العضو المراد استعراض صورته')
        .setRequired(false))
    .addBooleanOption(opt =>
      opt.setName('server_avatar')
        .setDescription('عرض صورة العضو المخصصة لهذا السيرفر إذا وُجدت')
        .setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const serverAvatar = interaction.options.getBoolean('server_avatar');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    let avatarUrl = target.displayAvatarURL({ size: 1024, dynamic: true });
    let title = `🖼️ صورة الحساب: ${target.tag}`;

    if (serverAvatar && member && member.avatar) {
      avatarUrl = member.avatarURL({ size: 1024, dynamic: true });
      title = `🖼️ صورة السيرفر المخصصة: ${target.tag}`;
    }

    const pngUrl = avatarUrl.replace(/\.(webp|gif|jpg|jpeg)/, '.png');
    const jpgUrl = avatarUrl.replace(/\.(webp|gif|png)/, '.jpg');

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(title)
      .setImage(avatarUrl)
      .setDescription(`[PNG](${pngUrl}) | [JPG](${jpgUrl}) | [رابط مباشر](${avatarUrl})`)
      .setFooter({ text: config.footer })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('تحميل بصيغة PNG')
        .setStyle(ButtonStyle.Link)
        .setURL(pngUrl),
      new ButtonBuilder()
        .setLabel('رابط الصورة الأصلي')
        .setStyle(ButtonStyle.Link)
        .setURL(avatarUrl)
    );

    await interaction.reply({ embeds: [embed], components: [row] });
  }
};
