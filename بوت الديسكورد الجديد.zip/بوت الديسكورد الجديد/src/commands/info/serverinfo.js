const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('عرض معلومات وإحصائيات تفصيلية عن السيرفر (Server Info)'),

  async execute(interaction) {
    const guild = interaction.guild;
    const owner = await guild.fetchOwner();

    const totalMembers = guild.memberCount;
    const humans = guild.members.cache.filter(m => !m.user.bot).size;
    const bots = guild.members.cache.filter(m => m.user.bot).size;

    const textChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText).size;
    const voiceChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size;
    const categories = guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory).size;

    const rolesCount = guild.roles.cache.size;
    const emojisCount = guild.emojis.cache.size;
    const boostsCount = guild.premiumSubscriptionCount || 0;
    const boostLevel = guild.premiumTier;

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`🏰 معلومات سيرفر: ${guild.name}`)
      .setThumbnail(guild.iconURL({ size: 512, extension: 'png' }))
      .setImage(guild.bannerURL({ size: 1024 }))
      .addFields(
        { name: '👑 الأونر (المالك)', value: `${owner.user.tag} (<@${owner.id}>)`, inline: true },
        { name: '🆔 آيدي السيرفر', value: `\`${guild.id}\``, inline: true },
        { name: '📅 تاريخ الإنشاء', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D> (<t:${Math.floor(guild.createdTimestamp / 1000)}:R>)`, inline: true },

        { name: '👥 الأعضاء', value: `> الإجمالي: **${totalMembers.toLocaleString()}**\n> بشر: **${humans}** | بوتات: **${bots}**`, inline: true },
        { name: '📁 الرومات', value: `> الإجمالي: **${guild.channels.cache.size}**\n> كتابية: **${textChannels}** | صوتية: **${voiceChannels}** | أقسام: **${categories}**`, inline: true },
        { name: '💎 البوستات', value: `> المستوى: **Tier ${boostLevel}**\n> عدد البوستات: **${boostsCount}** boost`, inline: true },

        { name: '🛡️ مستوى الأمان والتوثيق', value: `\`${guild.verificationLevel}\``, inline: true },
        { name: '🎨 الرتب والإيموجي', value: `> الرتب: **${rolesCount}**\n> الإيموجي: **${emojisCount}**`, inline: true },
        { name: '🌐 اللغة والمنطقة', value: `\`${guild.preferredLocale}\``, inline: true }
      )
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
