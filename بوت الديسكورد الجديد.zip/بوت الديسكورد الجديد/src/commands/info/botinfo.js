const { SlashCommandBuilder, EmbedBuilder, version: djsVersion } = require('discord.js');
const os = require('os');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('عرض إحصائيات ومعلومات تشغيل البوت التقنية (Bot Info & Stats)'),

  async execute(interaction) {
    const client = interaction.client;
    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    const uptimeStr = `${days} يوم و ${hours} ساعة و ${minutes} دقيقة و ${seconds} ثانية`;

    const memoryUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const totalMem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
    const ping = client.ws.ping;

    const totalUsers = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`🤖 بطاقة معلومات البوت: ${client.user.username}`)
      .setThumbnail(client.user.displayAvatarURL())
      .addFields(
        { name: '👑 اسم البوت', value: `\`${client.user.tag}\``, inline: true },
        { name: '⚡ سرعة الاستجابة (Ping)', value: `\`${ping} ms\``, inline: true },
        { name: '⏳ مدة التشغيل (Uptime)', value: `\`${uptimeStr}\``, inline: false },

        { name: '🏰 السيرفرات المتصلة', value: `\`${client.guilds.cache.size}\` سيرفر`, inline: true },
        { name: '👥 إجمالي الأعضاء المخدومين', value: `\`${totalUsers.toLocaleString()}\` عضو`, inline: true },
        { name: '⌨️ أوامر السلاش المسجلة', value: `\`${client.commands.size}\` أمر`, inline: true },

        { name: '💻 استهلاك الذاكرة (RAM)', value: `\`${memoryUsage} MB / ${totalMem} GB\``, inline: true },
        { name: '📦 إصدار Node.js', value: `\`${process.version}\``, inline: true },
        { name: '📚 إصدار Discord.js', value: `\`v${djsVersion}\``, inline: true }
      )
      .setFooter({ text: config.footer })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
