const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createWarningEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('استلام المكافأة والراتب اليومي مع بونص الأيام المتتالية (Daily Reward)'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const settings = db.getGuild(guildId);
    const symbol = settings.economy?.currencySymbol || '🪙';

    const userData = db.getUser(guildId, userId);
    const now = Date.now();
    const cooldown = 24 * 60 * 60 * 1000; // 24 hours
    const lastDaily = userData.lastDaily || 0;

    if (now - lastDaily < cooldown) {
      const remainingMs = cooldown - (now - lastDaily);
      const hours = Math.floor(remainingMs / (1000 * 60 * 60));
      const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));

      return interaction.reply({
        embeds: [createWarningEmbed('صبرك علينا يا باشا ✋', `أنت استلمت راتبك اليومي بالفعل!\nتقدر تستلم المكافأة الجاية بعد: **${hours} ساعة و ${minutes} دقيقة**`)],
        ephemeral: true
      });
    }

    // Check streak
    let streak = userData.dailyStreak || 0;
    if (now - lastDaily < cooldown * 2) {
      streak += 1;
    } else {
      streak = 1;
    }

    const minAmount = settings.economy?.dailyMin || 100;
    const maxAmount = settings.economy?.dailyMax || 300;
    const baseReward = Math.floor(Math.random() * (maxAmount - minAmount + 1)) + minAmount;
    const streakBonus = (streak - 1) * 25;
    const totalReward = baseReward + streakBonus;

    userData.wallet = (userData.wallet || 0) + totalReward;
    userData.lastDaily = now;
    userData.dailyStreak = streak;

    db.updateUser(guildId, userId, userData);

    const embed = createSuccessEmbed(
      'تم استلام الراتب اليومي بنجاح 🎁',
      `ألف هنا وشفا يا باشا! نزل في حسابك **${totalReward.toLocaleString()} ${symbol}**!\n` +
      `> **المكافأة الأساسية:** ${baseReward} ${symbol}\n` +
      `> **بونص الالتزام اليومي (Streak 🔥):** ${streakBonus} ${symbol} (اليوم رقم ${streak})\n` +
      `> **رصيدك الحالي بالمحفظة:** ${userData.wallet.toLocaleString()} ${symbol}`
    );

    await interaction.reply({ embeds: [embed] });
  }
};
