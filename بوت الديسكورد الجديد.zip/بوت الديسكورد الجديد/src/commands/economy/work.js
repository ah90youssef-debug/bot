const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createWarningEmbed } = require('../../utils/embed');

const jobs = [
  'اشتغلت كاشير في كوشري التحرير وطلعت بأوردرات زي الفل',
  'عملت مشروع تخرج لواحد صاحبك ونفحك قرشين حلوين',
  'صلحت عربية مرسيدس في ورشة الأسطى بلية وقبضت يوميتك',
  'وقفت على عربية كبده وسجق في وسط البلد وعملت مبيعات عالية',
  'سربست شاي وقهوة في قهوة الفيشاوي والزبائن روقت عليك ببقشيش',
  'كتبت كود برمجي لموقع شركة ناشئة وخدت الدفعة الأولى',
  'عملت ديزاين لوجو لمطعم شاورما ووافقوا عليه من أول تجربة',
  'وصلت دليفري على الموتوسيكل في عز الزحمة وخلصت كل الطلبات',
  'بعت كام حتة هدوم في سوق العتبة والزبون طلع مبسوط'
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('work')
    .setDescription('العمل وكسب عملات كوينز حلال بعرق جبينك (Work)'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const settings = db.getGuild(guildId);
    const symbol = settings.economy?.currencySymbol || '🪙';

    const userData = db.getUser(guildId, userId);
    const now = Date.now();
    const cooldown = 30 * 60 * 1000; // 30 minutes
    const lastWork = userData.lastWork || 0;

    if (now - lastWork < cooldown) {
      const remainingMs = cooldown - (now - lastWork);
      const minutes = Math.floor(remainingMs / (1000 * 60));
      const seconds = Math.floor((remainingMs % (1000 * 60)) / 1000);

      return interaction.reply({
        embeds: [createWarningEmbed('استريح شوية يا شقيان ☕', `أنت لسه مخلص شغل ومحتاج تاخد بريك!\nتقدر تشتغل تاني بعد: **${minutes} دقيقة و ${seconds} ثانية**`)],
        ephemeral: true
      });
    }

    const minAmount = settings.economy?.workMin || 50;
    const maxAmount = settings.economy?.workMax || 150;
    const reward = Math.floor(Math.random() * (maxAmount - minAmount + 1)) + minAmount;
    const randomJob = jobs[Math.floor(Math.random() * jobs.length)];

    userData.wallet = (userData.wallet || 0) + reward;
    userData.lastWork = now;

    db.updateUser(guildId, userId, userData);

    const embed = createSuccessEmbed(
      'عاش يا بطل! تم إنجاز العمل بنجاح 💪',
      `**المهمة:** ${randomJob}!\n` +
      `> **الأجر:** قبضت \`${reward} ${symbol}\` حلال عليك يا فنان.\n` +
      `> **المحفظة الآن:** \`${userData.wallet.toLocaleString()} ${symbol}\``
    );

    await interaction.reply({ embeds: [embed] });
  }
};
