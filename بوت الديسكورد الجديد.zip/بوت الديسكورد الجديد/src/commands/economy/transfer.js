const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('transfer')
    .setDescription('تحويل عملات كوينز لعضو آخر في السيرفر (Pay / Transfer)')
    .addUserOption(opt =>
      opt.setName('user')
        .setDescription('العضو المراد التحويل إليه')
        .setRequired(true))
    .addIntegerOption(opt =>
      opt.setName('amount')
        .setDescription('المبلغ المراد تحويله')
        .setMinValue(1)
        .setRequired(true)),

  async execute(interaction) {
    const sender = interaction.user;
    const recipient = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const guildId = interaction.guild.id;

    if (recipient.id === sender.id) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'بتحول لنفسك إزاي يعني يا معلم؟ 😂')],
        ephemeral: true
      });
    }

    if (recipient.bot) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'البوتات لا تستخدم الفلوس يا غالي!')],
        ephemeral: true
      });
    }

    const senderData = db.getUser(guildId, sender.id);
    if ((senderData.wallet || 0) < amount) {
      return interaction.reply({
        embeds: [createErrorEmbed('رصيد غير كافٍ', `معكش في محفظتك غير **${senderData.wallet || 0}** كوينز، والمبلغ المطلوب تحويله **${amount}**!`)],
        ephemeral: true
      });
    }

    const recipientData = db.getUser(guildId, recipient.id);
    const settings = db.getGuild(guildId);
    const symbol = settings.economy?.currencySymbol || '🪙';

    senderData.wallet -= amount;
    recipientData.wallet = (recipientData.wallet || 0) + amount;

    db.updateUser(guildId, sender.id, senderData);
    db.updateUser(guildId, recipient.id, recipientData);

    const embed = createSuccessEmbed(
      'تم التحويل بنجاح 💸',
      `قام **${sender}** بتحويل **${amount.toLocaleString()} ${symbol}** إلى **${recipient}** بنجاح!\n` +
      `> **رصيدك المتبقي:** ${senderData.wallet.toLocaleString()} ${symbol}`
    );

    await interaction.reply({ embeds: [embed] });
  }
};
