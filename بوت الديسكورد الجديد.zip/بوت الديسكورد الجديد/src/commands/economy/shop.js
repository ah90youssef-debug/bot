const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('عرض متجر السيرفر والرتب والمكافآت المتاحة للشراء (Server Shop)'),

  async execute(interaction) {
    const settings = db.getGuild(interaction.guild.id);
    const symbol = settings.economy?.currencySymbol || '🪙';
    const items = settings.economy?.shopItems || [];

    if (items.length === 0) {
      return interaction.reply({
        content: 'المتجر فاضي حالياً، الإدارة لسه ما ضافتش منتجات يا باشا!',
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`🛍️ متجر سيرفر: ${interaction.guild.name}`)
      .setDescription('تقدر تشتري أي عنصر من العناصر دي باستخدام كوينز السيرفر عبر الأمر `/buy [اسم أو كود العنصر]`:\n')
      .setThumbnail(interaction.guild.iconURL())
      .setFooter({ text: 'استخدم /buy لشراء أي رتبة أو عنصر' })
      .setTimestamp();

    items.forEach((item, index) => {
      const roleText = item.roleId ? `(رتبة: <@&${item.roleId}>)` : '';
      embed.addFields({
        name: `${index + 1}. ${item.name} — \`${item.price.toLocaleString()} ${symbol}\``,
        value: `> **الكود:** \`${item.id}\` ${roleText}\n> **الوصف:** ${item.description || 'عنصر مميز في السيرفر'}`
      });
    });

    await interaction.reply({ embeds: [embed] });
  }
};
