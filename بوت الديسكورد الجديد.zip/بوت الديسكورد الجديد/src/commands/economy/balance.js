const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('عرض رصيدك المالي ومحفظتك (Balance / Coins)')
    .addUserOption(opt =>
      opt.setName('user')
        .setDescription('العضو المراد فحص حسابه (اختياري)')
        .setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const settings = db.getGuild(interaction.guild.id);
    const symbol = settings.economy?.currencySymbol || '🪙';
    const currName = settings.economy?.currencyName || 'جنيه كوين';

    const userData = db.getUser(interaction.guild.id, target.id);
    const wallet = userData.wallet || 0;
    const bank = userData.bank || 0;
    const total = wallet + bank;

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`💼 المحفظة البنكية: ${target.tag}`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: '💵 الكاش (المحفظة)', value: `\`${wallet.toLocaleString()} ${symbol}\``, inline: true },
        { name: '🏦 البنك (الخزنة)', value: `\`${bank.toLocaleString()} ${symbol}\``, inline: true },
        { name: '💰 إجمالي الثروة', value: `\`${total.toLocaleString()} ${currName}\``, inline: false }
      )
      .setFooter({ text: 'للحصول على عملات يومية مجانية استخدم: /daily' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
