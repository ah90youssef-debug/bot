const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ecotop')
    .setDescription('عرض قائمة أثرى وأغنى أعضاء السيرفر (Richest Members)'),

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const settings = db.getGuild(guildId);
    const symbol = settings.economy?.currencySymbol || '🪙';

    const allUsers = db.getGuildUsers(guildId);
    allUsers.sort((a, b) => ((b.wallet || 0) + (b.bank || 0)) - ((a.wallet || 0) + (a.bank || 0)));

    const top10 = allUsers.slice(0, 10);
    if (top10.length === 0) {
      return interaction.reply({
        content: 'لسه مفيش أي بيانات اقتصادية مسجلة في السيرفر يا غالي.',
        ephemeral: true
      });
    }

    const medals = ['👑', '💎', '💰', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

    const lines = top10.map((u, i) => {
      const total = (u.wallet || 0) + (u.bank || 0);
      return `${medals[i] || `#${i + 1}`} <@${u.userId}> — **${total.toLocaleString()}** ${symbol}`;
    }).join('\n');

    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle(`🏦 قائمة هوامير وأثرياء سيرفر ${interaction.guild.name}`)
      .setDescription(lines)
      .setThumbnail(interaction.guild.iconURL())
      .setFooter({ text: 'ترتيب الحيتان وأصحاب الملايين في السيرفر 🤑' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
