const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('شراء رتبة أو عنصر من متجر السيرفر')
    .addStringOption(opt =>
      opt.setName('item_id')
        .setDescription('كود أو اسم العنصر في المتجر (استخدم /shop لمعرفة الأكواد)')
        .setRequired(true)),

  async execute(interaction) {
    const itemId = interaction.options.getString('item_id').trim().toLowerCase();
    const settings = db.getGuild(interaction.guild.id);
    const items = settings.economy?.shopItems || [];
    const symbol = settings.economy?.currencySymbol || '🪙';

    const item = items.find(i => i.id.toLowerCase() === itemId || i.name.toLowerCase() === itemId);
    if (!item) {
      return interaction.reply({
        embeds: [createErrorEmbed('عنصر غير موجود', `العنصر \`${itemId}\` مش موجود في المتجر يا باشا! افتح \`/shop\` وشوف المتاح.`)],
        ephemeral: true
      });
    }

    const userData = db.getUser(interaction.guild.id, interaction.user.id);
    if ((userData.wallet || 0) < item.price) {
      return interaction.reply({
        embeds: [createErrorEmbed('رصيد غير كافٍ', `سعر العنصر ده **${item.price.toLocaleString()} ${symbol}**، وأنت معاك في المحفظة **${(userData.wallet || 0).toLocaleString()} ${symbol}** بس! اشتغل أكتر يا فنان!`)],
        ephemeral: true
      });
    }

    // If item gives role
    if (item.roleId) {
      const role = interaction.guild.roles.cache.get(item.roleId);
      if (role) {
        if (interaction.member.roles.cache.has(role.id)) {
          return interaction.reply({
            embeds: [createErrorEmbed('موجود بالفعل', `أنت بالفعل معاك الرتبة **${role.name}** يا ريس!`)],
            ephemeral: true
          });
        }
        await interaction.member.roles.add(role).catch(() => {});
      }
    }

    // Deduct coins & add to inventory
    userData.wallet -= item.price;
    userData.inventory = userData.inventory || [];
    userData.inventory.push({ id: item.id, name: item.name, purchasedAt: Date.now() });

    db.updateUser(interaction.guild.id, interaction.user.id, userData);

    const embed = createSuccessEmbed(
      'مبروك عليك الشراء! 🎉',
      `تم شراء **${item.name}** بنجاح بسعر **${item.price.toLocaleString()} ${symbol}**!\n` +
      `> **رصيدك المتبقي في المحفظة:** ${userData.wallet.toLocaleString()} ${symbol}`
    );

    await interaction.reply({ embeds: [embed] });
  }
};
