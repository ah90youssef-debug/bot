const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const config = require('../../../config.json');

function getXpNeeded(level) {
  return 5 * (level * level) + 50 * level + 100;
}

function makeProgressBar(current, max, size = 12) {
  const percentage = Math.min(Math.max(current / max, 0), 1);
  const progress = Math.round(size * percentage);
  const emptyProgress = size - progress;
  const progressText = '🟩'.repeat(progress);
  const emptyProgressText = '⬛'.repeat(emptyProgress);
  const percentageText = Math.round(percentage * 100) + '%';
  return `${progressText}${emptyProgressText} **${percentageText}**`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('عرض بطاقة المستوى ونقاط الخبرة الخاصة بك أو بعضو آخر (Rank & XP)')
    .addUserOption(opt =>
      opt.setName('user')
        .setDescription('العضو المراد عرض بطاقته (اختياري)')
        .setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const guildId = interaction.guild.id;

    const allUsers = db.getGuildUsers(guildId);
    allUsers.sort((a, b) => (b.level * 10000 + b.xp) - (a.level * 10000 + a.xp));

    const rankIndex = allUsers.findIndex(u => u.userId === target.id);
    const serverRank = rankIndex !== -1 ? `#${rankIndex + 1}` : '#-';

    const userData = db.getUser(guildId, target.id);
    const needed = getXpNeeded(userData.level);
    const bar = makeProgressBar(userData.xp, needed, 10);

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`🏆 بطاقة مستوى: ${target.tag}`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: '🎖️ المستوى (Level)', value: `\`${userData.level}\``, inline: true },
        { name: '📊 ترتيب السيرفر (Rank)', value: `\`${serverRank}\``, inline: true },
        { name: '✨ نقاط الخبرة (XP)', value: `\`${userData.xp} / ${needed}\``, inline: true },
        { name: '📈 شريط التقدم', value: bar, inline: false }
      )
      .setFooter({ text: 'كل رسالة بتكتبها بتديك XP وترفع مستواك يا بطل!' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
