const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('عرض قائمة المتصدرين في المستويات ونشاط السيرفر (Top Levels)'),

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const allUsers = db.getGuildUsers(guildId);

    allUsers.sort((a, b) => (b.level * 10000 + b.xp) - (a.level * 10000 + a.xp));
    const top10 = allUsers.slice(0, 10);

    if (top10.length === 0) {
      return interaction.reply({
        content: 'لسه مفيش حد اتكلم أو سجل نقاط خبرة في السيرفر يا غالي!',
        ephemeral: true
      });
    }

    const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

    const lines = top10.map((u, i) => {
      const medal = medals[i] || `#${i + 1}`;
      return `${medal} <@${u.userId}> — **المستوى ${u.level}** (\`${u.xp} XP\`)`;
    }).join('\n');

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`🏆 قائمة الأساطير والمتصدرين في ${interaction.guild.name}`)
      .setDescription(lines)
      .setThumbnail(interaction.guild.iconURL())
      .setFooter({ text: 'ترتيب الأعضاء الأكثر تفاعلاً في السيرفر 👑' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
