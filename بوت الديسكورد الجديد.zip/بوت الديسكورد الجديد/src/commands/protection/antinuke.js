const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antinuke')
    .setDescription('إدارة والتحكم في نظام الحماية والأمان (Anti-Nuke & Anti-Raid)')
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('عرض الحالة الحالية لأنظمة الحماية والأمان'))
    .addSubcommand(sub =>
      sub.setName('toggle')
        .setDescription('تفعيل أو تعطيل نظام الحماية')
        .addStringOption(opt =>
          opt.setName('system')
            .setDescription('اختر النظام')
            .setRequired(true)
            .addChoices(
              { name: 'حماية الرومات والرتب (Anti-Nuke)', value: 'antinuke' },
              { name: 'حماية الدخول الجماعي (Anti-Raid)', value: 'antiraid' }
            ))
        .addBooleanOption(opt =>
          opt.setName('enabled')
            .setDescription('تفعيل (True) أو تعطيل (False)')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('whitelist')
        .setDescription('إضافة أو إزالة شخص موثوق من القائمة البيضاء')
        .addStringOption(opt =>
          opt.setName('action')
            .setDescription('نوع العملية')
            .setRequired(true)
            .addChoices(
              { name: 'إضافة (Add)', value: 'add' },
              { name: 'إزالة (Remove)', value: 'remove' }
            ))
        .addUserOption(opt =>
          opt.setName('user')
            .setDescription('العضو أو البوت')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('channel')
        .setDescription('تحديد روم تنبيهات الحماية والأمان المشبوهة')
        .addChannelOption(opt =>
          opt.setName('channel')
            .setDescription('الروم المخصص للتنبيهات')
            .setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    // Only server owner or administrators
    if (interaction.user.id !== interaction.guild.ownerId && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({
        embeds: [createErrorEmbed('صلاحيات غير كافية', 'هذا الأمر مخصص لأونر السيرفر ومديري النظام فقط!')],
        ephemeral: true
      });
    }

    const sub = interaction.options.getSubcommand();
    const settings = db.getGuild(interaction.guild.id);

    if (sub === 'status') {
      const isAntiNuke = settings.antiNuke.enabled ? '🟢 مفعل' : '🔴 معطل';
      const isAntiRaid = settings.antiRaid.enabled ? '🟢 مفعل' : '🔴 معطل';
      const whitelist = settings.antiNuke.whitelist || [];
      const whitelistDisplay = whitelist.length > 0 ? whitelist.map(id => `<@${id}>`).join(', ') : 'لا يوجد أعضاء في القائمة البيضاء';
      const alertChannel = settings.antiNuke.alertChannelId ? `<#${settings.antiNuke.alertChannelId}>` : 'غير محدد';

      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('🛡️ درع الحماية والأمان (Anti-Nuke & Anti-Raid)')
        .setDescription('جميع أنظمة الدفاع عن السيرفر ضد التخريب والهجمات:')
        .addFields(
          { name: 'حماية الرومات والرتب (Anti-Nuke)', value: `${isAntiNuke}\n> الحد الأقصى لحذف الرومات: 3/دقيقة\n> الحد الأقصى لحذف الرتب: 3/دقيقة\n> الحد الأقصى للباند الجماعي: 3/دقيقة`, inline: false },
          { name: 'حماية الهجوم السريع (Anti-Raid)', value: `${isAntiRaid}\n> رصد دخول أكثر من 5 حسابات خلال 10 ثوانٍ`, inline: false },
          { name: 'روم التنبيهات الأمنية', value: alertChannel, inline: true },
          { name: 'القائمة البيضاء الموثوقة (Whitelist)', value: whitelistDisplay, inline: false }
        )
        .setFooter({ text: 'للتعديل استخدم /antinuke toggle أو /antinuke whitelist' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'toggle') {
      const sys = interaction.options.getString('system');
      const enabled = interaction.options.getBoolean('enabled');

      db.updateGuild(interaction.guild.id, g => {
        if (sys === 'antinuke') g.antiNuke.enabled = enabled;
        if (sys === 'antiraid') g.antiRaid.enabled = enabled;
      });

      const label = sys === 'antinuke' ? 'Anti-Nuke' : 'Anti-Raid';
      const statusText = enabled ? 'تفعيل' : 'تعطيل';

      return interaction.reply({
        embeds: [createSuccessEmbed('تم تحديث الإعدادات 🛡️', `تم **${statusText}** نظام **${label}** بنجاح في السيرفر!`)]
      });
    }

    if (sub === 'whitelist') {
      const action = interaction.options.getString('action');
      const targetUser = interaction.options.getUser('user');

      const list = settings.antiNuke.whitelist || [];
      if (action === 'add') {
        if (!list.includes(targetUser.id)) list.push(targetUser.id);
      } else {
        const idx = list.indexOf(targetUser.id);
        if (idx !== -1) list.splice(idx, 1);
      }

      db.updateGuild(interaction.guild.id, g => {
        g.antiNuke.whitelist = list;
      });

      return interaction.reply({
        embeds: [createSuccessEmbed('القائمة البيضاء', `تم ${action === 'add' ? 'إضافة' : 'إزالة'} العضو **${targetUser.tag}** ${action === 'add' ? 'إلى' : 'من'} القائمة البيضاء بنجاح!`)]
      });
    }

    if (sub === 'channel') {
      const channel = interaction.options.getChannel('channel');
      db.updateGuild(interaction.guild.id, g => {
        g.antiNuke.alertChannelId = channel.id;
        g.antiRaid.alertChannelId = channel.id;
      });

      return interaction.reply({
        embeds: [createSuccessEmbed('روم التنبيهات الأمنية', `تم تعيين ${channel} كروم لتنبيهات الحماية والأمان بنجاح!`)]
      });
    }
  }
};
