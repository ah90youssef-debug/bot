const { SlashCommandBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const { createWelcomeCard } = require('../../utils/canvas');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('welcome')
    .setDescription('إدارة وتخصيص نظام الترحيب والمغادرة')
    .addSubcommand(sub =>
      sub.setName('channel')
        .setDescription('تحديد روم الترحيب بالأعضاء الجدد')
        .addChannelOption(opt =>
          opt.setName('channel')
            .setDescription('روم الترحيب')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('leavechannel')
        .setDescription('تحديد روم المغادرة وتوديع الأعضاء')
        .addChannelOption(opt =>
          opt.setName('channel')
            .setDescription('روم المغادرة')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('autorole')
        .setDescription('تحديد الرتبة التلقائية للأعضاء الجدد فور دخولهم (Auto-Role)')
        .addRoleOption(opt =>
          opt.setName('role')
            .setDescription('الرتبة المعطاة للأعضاء الجدد')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('toggle')
        .setDescription('تفعيل أو تعطيل الترحيب بالصورة')
        .addBooleanOption(opt =>
          opt.setName('image')
            .setDescription('تفعيل بطاقة الترحيب المصممة بالصورة')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('test')
        .setDescription('تجربة بطاقة الترحيب ورسالة الترحيب حالاً في هذا الروم'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'channel') {
      const channel = interaction.options.getChannel('channel');
      db.updateGuild(interaction.guild.id, g => {
        g.welcome.channelId = channel.id;
        g.welcome.enabled = true;
      });
      return interaction.reply({
        embeds: [createSuccessEmbed('روم الترحيب', `تم تعيين ${channel} كروم للترحيب بالأعضاء الجدد بنجاح! 🎉`)]
      });
    }

    if (sub === 'leavechannel') {
      const channel = interaction.options.getChannel('channel');
      db.updateGuild(interaction.guild.id, g => {
        g.leave.channelId = channel.id;
        g.leave.enabled = true;
      });
      return interaction.reply({
        embeds: [createSuccessEmbed('روم المغادرة', `تم تعيين ${channel} كروم لتوديع الأعضاء المغادرين!`)]
      });
    }

    if (sub === 'autorole') {
      const role = interaction.options.getRole('role');
      db.updateGuild(interaction.guild.id, g => {
        g.welcome.autoRoleId = role.id;
      });
      return interaction.reply({
        embeds: [createSuccessEmbed('الرتبة التلقائية (Auto-Role)', `تم تعيين الرتبة **${role.name}** لتعطى تلقائياً لأي عضو جديد ينضم للسيرفر! 👑`)]
      });
    }

    if (sub === 'toggle') {
      const imgEnabled = interaction.options.getBoolean('image');
      db.updateGuild(interaction.guild.id, g => {
        g.welcome.imageEnabled = imgEnabled;
      });
      return interaction.reply({
        embeds: [createSuccessEmbed('إعدادات الصورة', `تم ${imgEnabled ? 'تفعيل' : 'تعطيل'} بطاقة الترحيب المصممة بالصورة.`)]
      });
    }

    if (sub === 'test') {
      await interaction.deferReply();
      try {
        const imageBuffer = await createWelcomeCard(interaction.member);
        const attachment = new AttachmentBuilder(imageBuffer, { name: 'welcome-card.png' });

        const settings = db.getGuild(interaction.guild.id);
        const welcomeText = (settings.welcome.message || 'منور يا {user} في سيرفر **{server}**!')
          .replace(/{user}/g, interaction.user.toString())
          .replace(/{server}/g, interaction.guild.name)
          .replace(/{count}/g, interaction.guild.memberCount.toString());

        await interaction.editReply({
          content: welcomeText,
          files: [attachment]
        });
      } catch (err) {
        await interaction.editReply({
          embeds: [createErrorEmbed('خطأ في توليد الصورة', err.message)]
        });
      }
    }
  }
};
