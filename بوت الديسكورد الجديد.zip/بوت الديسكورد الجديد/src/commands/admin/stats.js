const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('إعداد وتحديث رومات إحصائيات السيرفر التلقائية (Server Stats Counters)')
    .addSubcommand(sub =>
      sub.setName('setup')
        .setDescription('إنشاء قسم ورومات صوتية تعرض عدد الأعضاء والبوتات والرومات تلقائياً'))
    .addSubcommand(sub =>
      sub.setName('disable')
        .setDescription('تعطيل نظام إحصائيات السيرفر'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'setup') {
      await interaction.deferReply({ ephemeral: true });

      try {
        // Create category
        const category = await guild.channels.create({
          name: '📊 إحصائيات السيرفر',
          type: ChannelType.GuildCategory,
          permissionOverwrites: [
            {
              id: guild.id,
              deny: ['Connect'],
              allow: ['ViewChannel']
            }
          ]
        });

        // Total members channel
        const totalMembers = guild.memberCount;
        const memberChan = await guild.channels.create({
          name: `👥 الأعضاء: ${totalMembers.toLocaleString()}`,
          type: ChannelType.GuildVoice,
          parent: category.id,
          permissionOverwrites: [
            {
              id: guild.id,
              deny: ['Connect'],
              allow: ['ViewChannel']
            }
          ]
        });

        // Bots channel
        const botsCount = guild.members.cache.filter(m => m.user.bot).size;
        const botChan = await guild.channels.create({
          name: `🤖 البوتات: ${botsCount}`,
          type: ChannelType.GuildVoice,
          parent: category.id,
          permissionOverwrites: [
            {
              id: guild.id,
              deny: ['Connect'],
              allow: ['ViewChannel']
            }
          ]
        });

        // Channels channel
        const totalChannels = guild.channels.cache.size;
        const channelChan = await guild.channels.create({
          name: `📁 الرومات: ${totalChannels}`,
          type: ChannelType.GuildVoice,
          parent: category.id,
          permissionOverwrites: [
            {
              id: guild.id,
              deny: ['Connect'],
              allow: ['ViewChannel']
            }
          ]
        });

        db.updateGuild(guild.id, g => {
          g.serverStats = {
            enabled: true,
            categoryId: category.id,
            membersChannelId: memberChan.id,
            botsChannelId: botChan.id,
            channelsChannelId: channelChan.id
          };
        });

        await interaction.editReply({
          embeds: [createSuccessEmbed('تم إعداد إحصائيات السيرفر بنجاح 📊', 'تم إنشاء القسم والرومات الصوتية بنجاح، وسيتم تحديثها تلقائياً كل 10 دقائق!')]
        });
      } catch (err) {
        await interaction.editReply({
          embeds: [createErrorEmbed('خطأ في الصلاحيات', 'تأكد أن البوت يمتلك صلاحية Manage Channels و Move Members!')]
        });
      }
    }

    if (sub === 'disable') {
      db.updateGuild(guild.id, g => {
        if (g.serverStats) g.serverStats.enabled = false;
      });

      return interaction.reply({
        embeds: [createSuccessEmbed('تم التعطيل', 'تم إيقاف التحديث التلقائي لإحصائيات السيرفر.')],
        ephemeral: true
      });
    }
  }
};
