const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('settings')
    .setDescription('مركز التحكم في إعدادات وتفعيل أنظمة البوت داخل السيرفر (Settings)')
    .addSubcommand(sub =>
      sub.setName('view')
        .setDescription('عرض لوحة الإعدادات وحالة جميع الأنظمة الحالية'))
    .addSubcommand(sub =>
      sub.setName('toggle')
        .setDescription('تفعيل أو تعطيل أي نظام في البوت بضغطة زر')
        .addStringOption(opt =>
          opt.setName('system')
            .setDescription('اختر النظام')
            .setRequired(true)
            .addChoices(
              { name: '👋 نظام الترحيب (Welcome)', value: 'welcome' },
              { name: '🚪 نظام المغادرة (Leave)', value: 'leave' },
              { name: '📜 نظام اللوجات الشامل (Audit Logs)', value: 'logs' },
              { name: '🎫 نظام التذاكر (Tickets)', value: 'tickets' },
              { name: '🏆 نظام المستويات والـ XP', value: 'levels' },
              { name: '🪙 نظام الاقتصاد والكوينز', value: 'economy' },
              { name: '⚡ نظام العقوبات التلقائية للتحذيرات', value: 'autopunish' }
            ))
        .addBooleanOption(opt =>
          opt.setName('status')
            .setDescription('تفعيل (True) أو تعطيل (False)')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('logs')
        .setDescription('تحديد رومات اللوجات وسجل العقوبات')
        .addChannelOption(opt =>
          opt.setName('audit_channel')
            .setDescription('روم اللوجات العامة (رسائل، رومات، رتب، دخول/خروج)')
            .setRequired(false))
        .addChannelOption(opt =>
          opt.setName('mod_channel')
            .setDescription('روم عقوبات الإدارة (Ban / Kick / Timeout / Warns)')
            .setRequired(false)))
    .addSubcommand(sub =>
      sub.setName('roles')
        .setDescription('تحديد الرتب الإدارية للبوت')
        .addRoleOption(opt =>
          opt.setName('admin_role')
            .setDescription('رتبة الإدارة العليا (Admin)')
            .setRequired(false))
        .addRoleOption(opt =>
          opt.setName('mod_role')
            .setDescription('رتبة المشرفين (Moderator)')
            .setRequired(false)))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const settings = db.getGuild(interaction.guild.id);

    if (sub === 'view') {
      const wStatus = settings.welcome?.enabled ? '🟢 مفعل' : '🔴 معطل';
      const lStatus = settings.leave?.enabled ? '🟢 مفعل' : '🔴 معطل';
      const logStatus = settings.logs?.enabled ? '🟢 مفعل' : '🔴 معطل';
      const tStatus = settings.tickets?.enabled ? '🟢 مفعل' : '🔴 معطل';
      const anStatus = settings.antiNuke?.enabled ? '🟢 مفعل' : '🔴 معطل';
      const arStatus = settings.antiRaid?.enabled ? '🟢 مفعل' : '🔴 معطل';
      const lvlStatus = settings.levels?.enabled ? '🟢 مفعل' : '🔴 معطل';
      const ecoStatus = settings.economy?.enabled ? '🟢 مفعل' : '🔴 معطل';
      const autoPunishStatus = settings.moderation?.autoPunishment?.enabled ? '🟢 مفعل' : '🔴 معطل';

      const wChan = settings.welcome?.channelId ? `<#${settings.welcome.channelId}>` : 'غير محدد';
      const lChan = settings.leave?.channelId ? `<#${settings.leave.channelId}>` : 'غير محدد';
      const logChan = settings.logs?.channelId ? `<#${settings.logs.channelId}>` : 'غير محدد';
      const modChan = settings.moderation?.logChannelId ? `<#${settings.moderation.logChannelId}>` : 'غير محدد';
      const tCat = settings.tickets?.categoryId ? `<#${settings.tickets.categoryId}>` : 'غير محدد';
      const secChan = settings.antiNuke?.alertChannelId ? `<#${settings.antiNuke.alertChannelId}>` : 'غير محدد';
      const autoRole = settings.welcome?.autoRoleId ? `<@&${settings.welcome.autoRoleId}>` : 'لا يوجد';

      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(`⚙️ لوحة تحكم وإعدادات: ${interaction.guild.name}`)
        .setDescription('حالة جميع الأنظمة والرومات المسجلة في السيرفر حالياً:\n')
        .addFields(
          {
            name: '👋 نظام الترحيب والمغادرة',
            value: `> الحالة: ${wStatus} | المغادرة: ${lStatus}\n> روم الترحيب: ${wChan}\n> روم المغادرة: ${lChan}\n> الرتبة التلقائية: ${autoRole}\n> بطاقة الصورة: ${settings.welcome?.imageEnabled ? 'مفعلة' : 'معطلة'}`,
            inline: false
          },
          {
            name: '📜 نظام اللوجات والعقوبات',
            value: `> لوجات السيرفر العامة: ${logStatus} (${logChan})\n> لوجات عقوبات الإدارة: ${modChan}`,
            inline: false
          },
          {
            name: '🎫 نظام التذاكر والدعم الفني',
            value: `> الحالة: ${tStatus}\n> قسم التذاكر: ${tCat}\n> إجمالي التذاكر المنشأة: \`${settings.tickets?.counter || 0}\``,
            inline: false
          },
          {
            name: '🛡️ الحماية والأمان (Anti-Nuke & Anti-Raid)',
            value: `> Anti-Nuke: ${anStatus} | Anti-Raid: ${arStatus}\n> روم التنبيهات الأمنية: ${secChan}\n> القائمة البيضاء: \`${(settings.antiNuke?.whitelist || []).length}\` عضو`,
            inline: false
          },
          {
            name: '🏆 المستويات والاقتصاد',
            value: `> المستويات: ${lvlStatus} | الاقتصاد: ${ecoStatus}\n> رمز العملة: \`${settings.economy?.currencySymbol || '🪙'}\`\n> العقوبات التلقائية للتحذيرات: ${autoPunishStatus}`,
            inline: false
          }
        )
        .setThumbnail(interaction.guild.iconURL())
        .setFooter({ text: 'لتعديل أي نظام استخدم: /settings toggle أو /welcome أو /antinuke' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'toggle') {
      const sys = interaction.options.getString('system');
      const status = interaction.options.getBoolean('status');

      db.updateGuild(interaction.guild.id, g => {
        if (sys === 'welcome') g.welcome.enabled = status;
        if (sys === 'leave') g.leave.enabled = status;
        if (sys === 'logs') g.logs.enabled = status;
        if (sys === 'tickets') g.tickets.enabled = status;
        if (sys === 'levels') g.levels.enabled = status;
        if (sys === 'economy') g.economy.enabled = status;
        if (sys === 'autopunish') {
          if (!g.moderation.autoPunishment) g.moderation.autoPunishment = {};
          g.moderation.autoPunishment.enabled = status;
        }
      });

      const statusText = status ? 'تفعيل' : 'تعطيل';
      return interaction.reply({
        embeds: [createSuccessEmbed('تم تحديث النظام ⚙️', `تم **${statusText}** النظام المحدد بنجاح في السيرفر!`)]
      });
    }

    if (sub === 'logs') {
      const auditChan = interaction.options.getChannel('audit_channel');
      const modChan = interaction.options.getChannel('mod_channel');

      db.updateGuild(interaction.guild.id, g => {
        if (auditChan) {
          g.logs.channelId = auditChan.id;
          g.logs.enabled = true;
        }
        if (modChan) {
          g.moderation.logChannelId = modChan.id;
        }
      });

      return interaction.reply({
        embeds: [createSuccessEmbed('رومات اللوجات', 'تم حفظ رومات اللوجات والعقوبات الإدارية بنجاح يا باشا!')]
      });
    }

    if (sub === 'roles') {
      const adminRole = interaction.options.getRole('admin_role');
      const modRole = interaction.options.getRole('mod_role');

      db.updateGuild(interaction.guild.id, g => {
        if (adminRole && !g.general.adminRoles.includes(adminRole.id)) {
          g.general.adminRoles.push(adminRole.id);
        }
        if (modRole && !g.general.modRoles.includes(modRole.id)) {
          g.general.modRoles.push(modRole.id);
        }
      });

      return interaction.reply({
        embeds: [createSuccessEmbed('الرتب الإدارية', 'تم تسجيل الرتب الإدارية بنجاح!')]
      });
    }
  }
};
