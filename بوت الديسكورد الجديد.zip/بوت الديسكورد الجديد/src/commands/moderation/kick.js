const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const db = require('../../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('طرد عضو من السيرفر مع إمكانية رجوعه (Kick)')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('العضو المراد طرده')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('سبب الطرد')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'بدون سبب محدد';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'العضو ده مش موجود في السيرفر حالياً.')],
        ephemeral: true
      });
    }

    if (target.id === interaction.user.id) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'مش هينفع تطرد نفسك يا ريس! 😄')],
        ephemeral: true
      });
    }

    if (!member.kickable) {
      return interaction.reply({
        embeds: [createErrorEmbed('صلاحيات غير كافية', 'مش هقدر أطرد العضو ده عشان رتبته أعلى مني!')],
        ephemeral: true
      });
    }

    try {
      await target.send({
        embeds: [createErrorEmbed('تم طردك', `تم طردك من سيرفر **${interaction.guild.name}**\n**السبب:** ${reason}\n**المسؤول:** ${interaction.user.tag}`)]
      });
    } catch (_) {}

    await member.kick(`${reason} | بواسطة ${interaction.user.tag}`);

    const embed = createSuccessEmbed(
      'تم الطرد بنجاح 👢',
      `تم طرد العضو **${target.tag}** من السيرفر!\n> **السبب:** ${reason}\n> **بواسطة:** ${interaction.user}`
    );

    await interaction.reply({ embeds: [embed] });

    const settings = db.getGuild(interaction.guild.id);
    if (settings.moderation.logChannelId) {
      const logChannel = interaction.guild.channels.cache.get(settings.moderation.logChannelId);
      if (logChannel) {
        logChannel.send({ embeds: [embed] });
      }
    }
  }
};
