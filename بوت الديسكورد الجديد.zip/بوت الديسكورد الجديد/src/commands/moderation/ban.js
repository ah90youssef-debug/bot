const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const db = require('../../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('حظر عضو من السيرفر نهائياً (Ban)')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('العضو المراد حظره')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('سبب الحظر')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'بدون سبب محدد';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (target.id === interaction.user.id) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'يا راجل هتحظر نفسك إزاي يعني؟ 😂')],
        ephemeral: true
      });
    }

    if (target.id === interaction.client.user.id) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'عايز تحظرني أنا؟ عيب عليك ده أنا اللي حاميك! 😎')],
        ephemeral: true
      });
    }

    if (member && !member.bannable) {
      return interaction.reply({
        embeds: [createErrorEmbed('صلاحيات غير كافية', 'مش هقدر أحظر العضو ده عشان رتبته أعلى مني أو هو الأونر يا غالي!')],
        ephemeral: true
      });
    }

    // Send DM to member before banning
    try {
      await target.send({
        embeds: [createErrorEmbed('تم حظرك', `تم حظرك من سيرفر **${interaction.guild.name}**\n**السبب:** ${reason}\n**المسؤول:** ${interaction.user.tag}`)]
      });
    } catch (_) {}

    await interaction.guild.members.ban(target.id, { reason: `${reason} | بواسطة ${interaction.user.tag}` });

    const embed = createSuccessEmbed(
      'تم الحظر بنجاح 🔨',
      `تم حظر العضو **${target.tag}** بنجاح من السيرفر يا باشا!\n> **السبب:** ${reason}\n> **بواسطة:** ${interaction.user}`
    );

    await interaction.reply({ embeds: [embed] });

    // Send to Mod Log channel
    const settings = db.getGuild(interaction.guild.id);
    if (settings.moderation.logChannelId) {
      const logChannel = interaction.guild.channels.cache.get(settings.moderation.logChannelId);
      if (logChannel) {
        logChannel.send({ embeds: [embed] });
      }
    }
  }
};
