const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('مسح عدد محدد من الرسائل في الروم الحالي (Clear/Purge)')
    .addIntegerOption(option =>
      option.setName('amount')
        .setDescription('عدد الرسائل المراد مسحها (من 1 إلى 100)')
        .setMinValue(1)
        .setMaxValue(100)
        .setRequired(true))
    .addUserOption(option =>
      option.setName('user')
        .setDescription('تصفية الرسائل لعضو محدد فقط (اختياري)')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const filterUser = interaction.options.getUser('user');

    await interaction.deferReply({ ephemeral: true });

    try {
      const messages = await interaction.channel.messages.fetch({ limit: amount });
      let filteredMessages = messages;

      if (filterUser) {
        filteredMessages = messages.filter(m => m.author.id === filterUser.id);
      }

      const deleted = await interaction.channel.bulkDelete(filteredMessages, true);

      const msg = filterUser
        ? `تم مسح **${deleted.size}** رسالة خاصة بالعضو **${filterUser.tag}** بنجاح! 🧹`
        : `تم تنظيف الروم ومسح **${deleted.size}** رسالة بنجاح يا باشا! 🧹`;

      await interaction.editReply({
        embeds: [createSuccessEmbed('تم المسح بنجاح', msg)]
      });
    } catch (err) {
      await interaction.editReply({
        embeds: [createErrorEmbed('فشل المسح', 'لا يمكن مسح الرسائل التي مر عليها أكثر من 14 يوم بسبب قيود ديسكورد.')]
      });
    }
  }
};
