const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ms = require('ms');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const db = require('../../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('إعطاء تايم اوت (إسكات مؤقت) لعضو (Timeout)')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('العضو المراد إسكاته')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('duration')
        .setDescription('المدة (مثال: 10m, 1h, 1d)')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('سبب التايم اوت')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const durationInput = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'بدون سبب محدد';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'العضو غير موجود في السيرفر.')],
        ephemeral: true
      });
    }

    if (!member.moderatable) {
      return interaction.reply({
        embeds: [createErrorEmbed('صلاحيات غير كافية', 'مش هقدر أديله تايم اوت عشان رتبته أعلى مني يا باشا!')],
        ephemeral: true
      });
    }

    const durationMs = ms(durationInput);
    if (!durationMs || durationMs < 5000 || durationMs > 28 * 24 * 60 * 60 * 1000) {
      return interaction.reply({
        embeds: [createErrorEmbed('مدة غير صحيحة', 'برجاء كتابة مدة صحيحة ما بين 5 ثواني و 28 يوم (مثال: 5m, 1h, 1d).')],
        ephemeral: true
      });
    }

    try {
      await member.timeout(durationMs, `${reason} | بواسطة ${interaction.user.tag}`);

      const embed = createSuccessEmbed(
        'تم إعطاء تايم اوت ⏳',
        `تم إسكات العضو **${target.tag}** بنجاح!\n> **المدة:** ${durationInput}\n> **السبب:** ${reason}\n> **بواسطة:** ${interaction.user}`
      );

      await interaction.reply({ embeds: [embed] });

      const settings = db.getGuild(interaction.guild.id);
      if (settings.moderation.logChannelId) {
        const logChannel = interaction.guild.channels.cache.get(settings.moderation.logChannelId);
        if (logChannel) {
          logChannel.send({ embeds: [embed] });
        }
      }
    } catch (err) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'فشل في تطبيق التايم اوت: ' + err.message)],
        ephemeral: true
      });
    }
  }
};
