const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const db = require('../../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('إلغاء التايم اوت عن عضو وفك الإسكات')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('العضو المراد فك الإسكات عنه')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'العضو مش موجود في السيرفر.')],
        ephemeral: true
      });
    }

    if (!member.isCommunicationDisabled()) {
      return interaction.reply({
        embeds: [createErrorEmbed('تنبيه', 'العضو ده مش عليه تايم اوت أصلاً يا غالي!')],
        ephemeral: true
      });
    }

    await member.timeout(null, `تم إلغاء التايم اوت بواسطة ${interaction.user.tag}`);

    const embed = createSuccessEmbed(
      'تم إلغاء التايم اوت 🔊',
      `تم فك الإسكات عن العضو **${target.tag}** ويقدر يشارك ويتكلم دلوقتي!`
    );

    await interaction.reply({ embeds: [embed] });

    const settings = db.getGuild(interaction.guild.id);
    if (settings.moderation.logChannelId) {
      const logChannel = interaction.guild.channels.cache.get(settings.moderation.logChannelId);
      if (logChannel) {
        logChannel.send({ embeds: [embed] });
      }
    }
  }
};
