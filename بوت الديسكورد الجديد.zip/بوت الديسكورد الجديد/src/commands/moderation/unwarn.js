const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const db = require('../../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unwarn')
    .setDescription('إزالة تحذير محدد أو مسح كل تحذيرات عضو (Unwarn)')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('العضو المراد إزالة التحذير عنه')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('warn_id')
        .setDescription('رقم التحذير المراد حذفه (أو اكتب "all" لمسح الكل)')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const warnId = interaction.options.getString('warn_id').trim();
    const userData = db.getUser(interaction.guild.id, target.id);

    if (!userData.warnings || userData.warnings.length === 0) {
      return interaction.reply({
        embeds: [createErrorEmbed('تنبيه', `العضو **${target.tag}** معندوش أي تحذيرات مسجلة يا غالي.`)],
        ephemeral: true
      });
    }

    if (warnId.toLowerCase() === 'all') {
      const removedCount = userData.warnings.length;
      userData.warnings = [];
      db.updateUser(interaction.guild.id, target.id, userData);

      const embed = createSuccessEmbed(
        'تم مسح جميع التحذيرات 🧹',
        `تم مسح كافة التحذيرات (${removedCount} تحذير) الخاصة بالعضو **${target.tag}** بنجاح!`
      );
      return interaction.reply({ embeds: [embed] });
    }

    const index = userData.warnings.findIndex(w => w.id === warnId);
    if (index === -1) {
      return interaction.reply({
        embeds: [createErrorEmbed('غير موجود', `لم يتم العثور على تحذير برقم #${warnId} لهذا العضو. استخدم الأمر \`/warnings\` لعرض أرقام التحذيرات.`)],
        ephemeral: true
      });
    }

    userData.warnings.splice(index, 1);
    db.updateUser(interaction.guild.id, target.id, userData);

    const embed = createSuccessEmbed(
      'تم حذف التحذير ✅',
      `تم حذف التحذير رقم **#${warnId}** للعضو **${target.tag}**.\nالمتبقي له الآن: **${userData.warnings.length}** تحذيرات.`
    );
    await interaction.reply({ embeds: [embed] });
  }
};
