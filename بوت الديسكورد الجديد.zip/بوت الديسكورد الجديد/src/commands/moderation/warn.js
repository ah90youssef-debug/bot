const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed, createWarningEmbed } = require('../../utils/embed');
const db = require('../../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('إعطاء تحذير إداري لعضو (Warn)')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('العضو المراد تحذيره')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('سبب التحذير')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (target.bot) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'البوتات لا تستقبل تحذيرات يا ريس!')],
        ephemeral: true
      });
    }

    if (target.id === interaction.user.id) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'بتحذر نفسك ليه يا طيب؟ 😄')],
        ephemeral: true
      });
    }

    const userData = db.getUser(interaction.guild.id, target.id);
    const warnId = (userData.warnings.length + 1).toString();
    const newWarn = {
      id: warnId,
      moderatorId: interaction.user.id,
      moderatorTag: interaction.user.tag,
      reason,
      timestamp: Date.now()
    };

    userData.warnings.push(newWarn);
    db.updateUser(interaction.guild.id, target.id, userData);

    const totalWarns = userData.warnings.length;

    // Send DM to target
    try {
      await target.send({
        embeds: [createWarningEmbed('تحذير إداري جديد ⚠️', `لقد تلقيت تحذيراً في سيرفر **${interaction.guild.name}**\n**السبب:** ${reason}\n**عدد تحذيراتك الحالي:** ${totalWarns}`)]
      });
    } catch (_) {}

    // Check Auto-Punishment Thresholds
    const settings = db.getGuild(interaction.guild.id);
    let autoPunishText = '';

    if (settings.moderation.autoPunishment && settings.moderation.autoPunishment.enabled) {
      const thresholds = settings.moderation.autoPunishment.thresholds || [];
      const rule = thresholds.find(t => t.count === totalWarns);

      if (rule && member) {
        if (rule.action === 'timeout' && member.moderatable) {
          const duration = rule.durationMs || 3600000;
          await member.timeout(duration, `تجاوز عدد التحذيرات (${totalWarns} تحذيرات) تلقائياً`);
          autoPunishText = `\n⚡ **العقوبة التلقائية:** تم تطبيق تايم اوت لمدة ساعة لتجاوز الحد المسموح!`;
        } else if (rule.action === 'kick' && member.kickable) {
          await member.kick(`تجاوز عدد التحذيرات (${totalWarns} تحذيرات) تلقائياً`);
          autoPunishText = `\n⚡ **العقوبة التلقائية:** تم طرد العضو لتجاوز ${totalWarns} تحذيرات!`;
        } else if (rule.action === 'ban' && member.bannable) {
          await interaction.guild.members.ban(target.id, { reason: `تجاوز عدد التحذيرات (${totalWarns} تحذيرات) تلقائياً` });
          autoPunishText = `\n⚡ **العقوبة التلقائية:** تم حظر العضو نهائياً لتجاوز ${totalWarns} تحذيرات!`;
        }
      }
    }

    const embed = createSuccessEmbed(
      'تم إعطاء التحذير ⚠️',
      `تم تسجيل تحذير للعضو **${target.tag}** بنجاح!\n` +
      `> **رقم التحذير:** #${warnId}\n` +
      `> **السبب:** ${reason}\n` +
      `> **إجمالي التحذيرات:** ${totalWarns}\n` +
      `> **بواسطة:** ${interaction.user}${autoPunishText}`
    );

    await interaction.reply({ embeds: [embed] });

    if (settings.moderation.logChannelId) {
      const logChannel = interaction.guild.channels.cache.get(settings.moderation.logChannelId);
      if (logChannel) {
        logChannel.send({ embeds: [embed] });
      }
    }
  }
};
