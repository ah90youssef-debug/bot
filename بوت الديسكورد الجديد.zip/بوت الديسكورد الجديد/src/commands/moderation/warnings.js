const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../../database');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('عرض سجل تحذيرات عضو في السيرفر')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('العضو المراد استعراض تحذيراته')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const userData = db.getUser(interaction.guild.id, target.id);

    if (!userData.warnings || userData.warnings.length === 0) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(config.successColor)
            .setTitle(`سجل التحذيرات: ${target.tag}`)
            .setDescription(`✨ العضو ده زي الفل وملتزم بالقوانين، معندوش أي تحذيرات سابقة!`)
            .setThumbnail(target.displayAvatarURL())
            .setFooter({ text: config.footer })
        ]
      });
    }

    const warnList = userData.warnings.map(w => {
      const date = new Date(w.timestamp).toLocaleDateString('ar-EG');
      return `**#${w.id}** | **السبب:** ${w.reason}\n> بواسطة: <@${w.moderatorId}> بتاريخ: \`${date}\``;
    }).join('\n\n');

    const embed = new EmbedBuilder()
      .setColor(config.warningColor)
      .setTitle(`⚠️ سجل تحذيرات: ${target.tag} (${userData.warnings.length})`)
      .setDescription(warnList)
      .setThumbnail(target.displayAvatarURL())
      .setFooter({ text: 'لحذف تحذير استخدم: /unwarn' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
