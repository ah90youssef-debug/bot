const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const db = require('../../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('فك الحظر عن عضو بواسطة الآيدي بتاعه (Unban)')
    .addStringOption(option =>
      option.setName('userid')
        .setDescription('الـ ID بتاع العضو المحظور')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('سبب فك الحظر')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const userId = interaction.options.getString('userid');
    const reason = interaction.options.getString('reason') || 'تم العفو عنه بواسطة الإدارة';

    try {
      const banInfo = await interaction.guild.bans.fetch(userId).catch(() => null);
      if (!banInfo) {
        return interaction.reply({
          embeds: [createErrorEmbed('غير موجود', 'العضو ده مش محظور في السيرفر يا فنان!')],
          ephemeral: true
        });
      }

      await interaction.guild.members.unban(userId, `${reason} | بواسطة ${interaction.user.tag}`);

      const embed = createSuccessEmbed(
        'تم فك الحظر بنجاح 🕊️',
        `تم فك الحظر عن العضو **${banInfo.user.tag}** (${userId})\n> **السبب:** ${reason}\n> **بواسطة:** ${interaction.user}`
      );

      await interaction.reply({ embeds: [embed] });

      const settings = db.getGuild(interaction.guild.id);
      if (settings.moderation.logChannelId) {
        const logChannel = interaction.guild.channels.cache.get(settings.moderation.logChannelId);
        if (logChannel) {
          logChannel.send({ embeds: [embed] });
        }
      }
    } catch (err) {
      return interaction.reply({
        embeds: [createErrorEmbed('خطأ', 'حصل خطأ أو الآيدي المدخل غير صحيح.')],
        ephemeral: true
      });
    }
  }
};
