const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('إدارة ونشر نظام التذاكر والدعم الفني')
    .addSubcommand(sub =>
      sub.setName('panel')
        .setDescription('إرسال لوحة فتح التذاكر في الروم الحالي')
        .addStringOption(opt =>
          opt.setName('title')
            .setDescription('عنوان اللوحة')
            .setRequired(false))
        .addStringOption(opt =>
          opt.setName('description')
            .setDescription('وصف اللوحة')
            .setRequired(false)))
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('إضافة عضو إلى التذكرة الحالية')
        .addUserOption(opt =>
          opt.setName('user')
            .setDescription('العضو المراد إضافته')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('إزالة عضو من التذكرة الحالية')
        .addUserOption(opt =>
          opt.setName('user')
            .setDescription('العضو المراد إزالته')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('settings')
        .setDescription('ضبط إعدادات التذاكر (القسم، الرتب، لوج السجلات)')
        .addChannelOption(opt =>
          opt.setName('log_channel')
            .setDescription('روم حفظ سجلات التذاكر (Transcripts)')
            .setRequired(false))
        .addChannelOption(opt =>
          opt.setName('category')
            .setDescription('قسم التذاكر (Category)')
            .setRequired(false))
        .addRoleOption(opt =>
          opt.setName('support_role')
            .setDescription('رتبة طاقم الدعم المسؤولة عن التذاكر')
            .setRequired(false)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const settings = db.getGuild(interaction.guild.id);

    // 1. TICKET PANEL
    if (sub === 'panel') {
      const title = interaction.options.getString('title') || '🎫 مركز المساعدة والدعم الفني';
      const desc = interaction.options.getString('description') ||
        'أهلاً بيك يا غالي في نظام التذاكر الرسمي!\n' +
        'لفتح تذكرة والتواصل مع الإدارة مباشرة، اختر نوع استفسارك أو مشكلتك من القائمة أدناه:\n\n' +
        '🛠️ **دعم فني واستفسارات:** لمشاكل السيرفر والتقنيات.\n' +
        '🚨 **شكاوى وبلاغات:** للإبلاغ عن مخالفة عضو أو إساءة.\n' +
        '🤝 **شراكات وإعلانات:** لطلبات التبادل والشراكة.\n' +
        '💡 **موضوع تاني:** لأي أمر آخر.';

      const panelEmbed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(title)
        .setDescription(desc)
        .setThumbnail(interaction.guild.iconURL())
        .setFooter({ text: 'فريق الدعم متاح لمساعدتكم دائماً 👑' })
        .setTimestamp();

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('ticket_select')
        .setPlaceholder('👇 اضغط هنا لاختيار نوع التذكرة...')
        .addOptions(
          settings.tickets.categories.map(c => ({
            label: c.label,
            value: c.id,
            description: c.description,
            emoji: c.emoji
          }))
        );

      const row = new ActionRowBuilder().addComponents(selectMenu);

      await interaction.channel.send({ embeds: [panelEmbed], components: [row] });
      return interaction.reply({
        content: 'تم إرسال لوحة التذاكر بنجاح في هذا الروم يا باشا! 🚀',
        ephemeral: true
      });
    }

    // 2. ADD MEMBER
    if (sub === 'add') {
      const ticket = db.getTicketByChannel(interaction.channel.id);
      if (!ticket) {
        return interaction.reply({
          embeds: [createErrorEmbed('تنبيه', 'الأمر ده مخصص لرومات التذاكر فقط يا غالي!')],
          ephemeral: true
        });
      }

      const targetUser = interaction.options.getUser('user');
      await interaction.channel.permissionOverwrites.edit(targetUser.id, {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true,
        AttachFiles: true
      });

      return interaction.reply({
        embeds: [createSuccessEmbed('تمت الإضافة', `تم إضافة العضو **${targetUser}** إلى التذكرة بنجاح! 👋`)]
      });
    }

    // 3. REMOVE MEMBER
    if (sub === 'remove') {
      const ticket = db.getTicketByChannel(interaction.channel.id);
      if (!ticket) {
        return interaction.reply({
          embeds: [createErrorEmbed('تنبيه', 'الأمر ده مخصص لرومات التذاكر فقط يا غالي!')],
          ephemeral: true
        });
      }

      const targetUser = interaction.options.getUser('user');
      await interaction.channel.permissionOverwrites.delete(targetUser.id);

      return interaction.reply({
        embeds: [createSuccessEmbed('تمت الإزالة', `تم إخراج العضو **${targetUser.tag}** من التذكرة.`)]
      });
    }

    // 4. SETTINGS
    if (sub === 'settings') {
      const logChannel = interaction.options.getChannel('log_channel');
      const category = interaction.options.getChannel('category');
      const supportRole = interaction.options.getRole('support_role');

      db.updateGuild(interaction.guild.id, g => {
        if (logChannel) g.tickets.logChannelId = logChannel.id;
        if (category) g.tickets.categoryId = category.id;
        if (supportRole && !g.tickets.supportRoleIds.includes(supportRole.id)) {
          g.tickets.supportRoleIds.push(supportRole.id);
        }
      });

      return interaction.reply({
        embeds: [createSuccessEmbed('تم تحديث إعدادات التذاكر', 'تم حفظ وتطبيق التعديلات بنجاح يا باشا!')],
        ephemeral: true
      });
    }
  }
};
