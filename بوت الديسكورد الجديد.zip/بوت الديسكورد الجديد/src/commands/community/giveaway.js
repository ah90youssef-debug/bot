const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const ms = require('ms');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('إدارة وإنشاء مسابقات وسحوبات القيف اواي (Giveaway)')
    .addSubcommand(sub =>
      sub.setName('start')
        .setDescription('بدء قيف اواي جديد')
        .addStringOption(opt =>
          opt.setName('prize')
            .setDescription('الجائزة')
            .setRequired(true))
        .addStringOption(opt =>
          opt.setName('duration')
            .setDescription('المدة (مثال: 10m, 1h, 1d)')
            .setRequired(true))
        .addIntegerOption(opt =>
          opt.setName('winners')
            .setDescription('عدد الفائزين (الافتراضي: 1)')
            .setMinValue(1)
            .setMaxValue(10)
            .setRequired(false)))
    .addSubcommand(sub =>
      sub.setName('reroll')
        .setDescription('إعادة سحب فائز جديد لقيف اواي منتهي')
        .addStringOption(opt =>
          opt.setName('message_id')
            .setDescription('آيدي رسالة القيف اواي')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('end')
        .setDescription('إنهاء قيف اواي نشط حالاً واختيار الفائزين')
        .addStringOption(opt =>
          opt.setName('message_id')
            .setDescription('آيدي رسالة القيف اواي')
            .setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageEvents),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'start') {
      const prize = interaction.options.getString('prize');
      const durationInput = interaction.options.getString('duration');
      const winnersCount = interaction.options.getInteger('winners') || 1;

      const durationMs = ms(durationInput);
      if (!durationMs || durationMs < 5000) {
        return interaction.reply({
          embeds: [createErrorEmbed('مدة غير صحيحة', 'برجاء كتابة مدة صحيحة (مثال: 30s, 10m, 2h, 1d).')],
          ephemeral: true
        });
      }

      const endsAt = Date.now() + durationMs;

      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle(`🎉 قيف أواي: ${prize}`)
        .setDescription(
          `اضغط على الزر بالأسفل للاشتراك في السحب والدخول في المنافسة!\n\n` +
          `> 🎁 **الجائزة:** ${prize}\n` +
          `> 👑 **عدد الفائزين:** ${winnersCount}\n` +
          `> ⏰ **ينتهي في:** <t:${Math.floor(endsAt / 1000)}:R> (<t:${Math.floor(endsAt / 1000)}:f>)\n` +
          `> 👤 **المنظم:** ${interaction.user}`
        )
        .setFooter({ text: 'سيد المعلمين | حظ موفق للجميع 🍀' })
        .setTimestamp(endsAt);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('giveaway_join')
          .setLabel('دخول السحب 🎉')
          .setStyle(ButtonStyle.Success)
      );

      await interaction.reply({ content: 'تم بدء القيف أواي بنجاح! 🚀', ephemeral: true });
      const giveawayMsg = await interaction.channel.send({ embeds: [embed], components: [row] });

      const giveawayData = {
        messageId: giveawayMsg.id,
        channelId: interaction.channel.id,
        guildId: interaction.guild.id,
        prize,
        winnersCount,
        endsAt,
        hostId: interaction.user.id,
        participants: [],
        ended: false
      };

      db.saveGiveaway(giveawayData);

      // Auto end timer
      setTimeout(async () => {
        try {
          const current = db.getGiveaway(giveawayMsg.id);
          if (!current || current.ended) return;

          current.ended = true;
          db.saveGiveaway(current);

          const participants = current.participants || [];
          let winners = [];

          if (participants.length > 0) {
            const shuffled = [...participants].sort(() => 0.5 - Math.random());
            winners = shuffled.slice(0, current.winnersCount);
          }

          const winnersText = winners.length > 0 ? winners.map(id => `<@${id}>`).join(', ') : 'لا يوجد مشاركون كافيون!';

          const endedEmbed = new EmbedBuilder()
            .setColor('#57F287')
            .setTitle(`🎉 انتهى القيف أواي: ${prize}`)
            .setDescription(
              `مبروك للفائزين معنا يا رجالة! 🥳\n\n` +
              `> 🎁 **الجائزة:** ${prize}\n` +
              `> 🏆 **الفائزون:** ${winnersText}\n` +
              `> 👥 **إجمالي المشاركين:** ${participants.length}\n` +
              `> 👤 **المنظم:** <@${current.hostId}>`
            )
            .setFooter({ text: 'قيف أواي منتهي' })
            .setTimestamp();

          await giveawayMsg.edit({ embeds: [endedEmbed], components: [] });

          if (winners.length > 0) {
            await interaction.channel.send({
              content: `🎉 ألف مبروك يا أبطال ${winnersText} فزتم بـ **${prize}**! تواصلوا مع المنظم لاستلام جائزتكم!`
            });
          }
        } catch (e) {
          console.error('Error ending giveaway timeout:', e.message);
        }
      }, durationMs);

      return;
    }

    if (sub === 'reroll') {
      const messageId = interaction.options.getString('message_id');
      const giveaway = db.getGiveaway(messageId);

      if (!giveaway) {
        return interaction.reply({
          embeds: [createErrorEmbed('غير موجود', 'لم يتم العثور على قيف اواي بهذا الآيدي.')],
          ephemeral: true
        });
      }

      const participants = giveaway.participants || [];
      if (participants.length === 0) {
        return interaction.reply({
          embeds: [createErrorEmbed('لا يوجد مشاركون', 'مفيش حد شارك في القيف اواي ده عشان نعمل إعادة سحب!')],
          ephemeral: true
        });
      }

      const winnerId = participants[Math.floor(Math.random() * participants.length)];
      return interaction.reply({
        content: `🎉 الفائز الجديد بعد إعادة السحب (Reroll) هو: <@${winnerId}>! ألف مبروك عليك **${giveaway.prize}** يا بطل!`
      });
    }

    if (sub === 'end') {
      const messageId = interaction.options.getString('message_id');
      const giveaway = db.getGiveaway(messageId);

      if (!giveaway || giveaway.ended) {
        return interaction.reply({
          embeds: [createErrorEmbed('تنبيه', 'القيف اواي ده منتهي بالفعل أو غير موجود.')],
          ephemeral: true
        });
      }

      giveaway.ended = true;
      db.saveGiveaway(giveaway);

      const participants = giveaway.participants || [];
      let winners = [];
      if (participants.length > 0) {
        const shuffled = [...participants].sort(() => 0.5 - Math.random());
        winners = shuffled.slice(0, giveaway.winnersCount);
      }

      const winnersText = winners.length > 0 ? winners.map(id => `<@${id}>`).join(', ') : 'لا يوجد مشاركون!';

      return interaction.reply({
        content: `تم إنهاء القيف اواي فوراً! 🏁\n🏆 الفائزون: ${winnersText}`
      });
    }
  }
};
