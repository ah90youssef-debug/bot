const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('نشر إعلان رسمي منسق في روم محدد (Announcement)')
    .addChannelOption(opt =>
      opt.setName('channel')
        .setDescription('الروم المراد نشر الإعلان فيه')
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('title')
        .setDescription('عنوان الإعلان')
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('message')
        .setDescription('نص الإعلان بالتفصيل')
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('mention')
        .setDescription('المنشن (Everyone / Here / لا يوجد)')
        .setRequired(false)
        .addChoices(
          { name: 'بدون منشن', value: 'none' },
          { name: '@everyone', value: 'everyone' },
          { name: '@here', value: 'here' }
        ))
    .setDefaultMemberPermissions(PermissionFlagsBits.MentionEveryone),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const title = interaction.options.getString('title');
    const message = interaction.options.getString('message');
    const mention = interaction.options.getString('mention') || 'none';

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`📢 ${title}`)
      .setDescription(message.replace(/\\n/g, '\n'))
      .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
      .setFooter({ text: `نُشر بواسطة: ${interaction.user.tag}` })
      .setTimestamp();

    let content = '';
    if (mention === 'everyone') content = '@everyone';
    else if (mention === 'here') content = '@here';

    await channel.send({ content: content || undefined, embeds: [embed] });

    await interaction.reply({
      content: `تم نشر الإعلان بنجاح في ${channel} يا باشا! 🚀`,
      ephemeral: true
    });
  }
};
