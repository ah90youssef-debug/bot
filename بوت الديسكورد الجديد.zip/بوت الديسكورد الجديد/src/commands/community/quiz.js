const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} = require('discord.js');
const db = require('../../database');
const config = require('../../../config.json');

const questions = [
  {
    q: 'ما هي عاصمة جمهورية مصر العربية؟',
    options: ['الإسكندرية', 'القاهرة', 'الجيزة', 'أسوان'],
    answer: 1
  },
  {
    q: 'من هو الهداف التاريخي لمنتخب مصر لكرة القدم؟',
    options: ['محمد صلاح', 'حسام حسن', 'محمد أبو تريكة', 'عماد متعب'],
    answer: 1
  },
  {
    q: 'أطول نهر في العالم يمر بمصر، ما اسمه؟',
    options: ['نهر الأمازون', 'نهر النيل', 'نهر الميسيسيبي', 'نهر الفرات'],
    answer: 1
  },
  {
    q: 'ما هو أكبر هرم من أهرامات الجيزة؟',
    options: ['هرم خوفو', 'هرم خفرع', 'هرم منقرع', 'هرم زوسر'],
    answer: 0
  },
  {
    q: 'من الأديب المصري الحاصل على جائزة نوبل في الأدب عام 1988؟',
    options: ['طه حسين', 'نجيب محفوظ', 'عباس العقاد', 'توفيق الحكيم'],
    answer: 1
  },
  {
    q: 'كم عدد سور القرآن الكريم؟',
    options: ['110', '112', '114', '120'],
    answer: 2
  }
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('quiz')
    .setDescription('لعبة مسابقات وأسئلة ثقافية ومصرية ممتعة مع جوائز كوينز (Quiz)'),

  async execute(interaction) {
    const item = questions[Math.floor(Math.random() * questions.length)];
    const rewardCoins = 50;

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🧠 سؤال التحدي والذكاء')
      .setDescription(`**${item.q}**\n\nالجائزة: \`${rewardCoins} 🪙\` لأول إجابة صحيحة خلال 30 ثانية!`)
      .setFooter({ text: 'اختر الإجابة الصحيحة بالضغط على الزر' })
      .setTimestamp();

    const row = new ActionRowBuilder();
    item.options.forEach((opt, idx) => {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`quiz_ans_${idx}`)
          .setLabel(opt)
          .setStyle(ButtonStyle.Secondary)
      );
    });

    const response = await interaction.reply({ embeds: [embed], components: [row] });

    const collector = response.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 30000
    });

    collector.on('collect', async i => {
      const selected = parseInt(i.customId.replace('quiz_ans_', ''));

      if (selected === item.answer) {
        // Winner
        const userData = db.getUser(i.guild.id, i.user.id);
        userData.wallet = (userData.wallet || 0) + rewardCoins;
        db.updateUser(i.guild.id, i.user.id, userData);

        collector.stop('answered');

        const winEmbed = new EmbedBuilder()
          .setColor('#57F287')
          .setTitle('🎉 إجابة صحيحة يا برنس!')
          .setDescription(`عاش يا **${i.user}**! الإجابة الصح هي: **${item.options[item.answer]}**\nوكسبت **${rewardCoins} 🪙** نزلوا في محفظتك فورا! 👑`)
          .setFooter({ text: 'انتهت المسابقة' });

        await i.update({ embeds: [winEmbed], components: [] });
      } else {
        await i.reply({
          content: 'للأسف إجابتك غير صحيحة يا غالي، حاول في السؤال القادم! 😅',
          ephemeral: true
        });
      }
    });

    collector.on('end', async (_, reason) => {
      if (reason === 'time') {
        const timeoutEmbed = new EmbedBuilder()
          .setColor('#ED4245')
          .setTitle('⏰ انتهى الوقت!')
          .setDescription(`للأسف محدش جاوب في الوقت المحدد!\nالإجابة الصحيحة كانت: **${item.options[item.answer]}**`)
          .setFooter({ text: 'حظ أوفر المرة الجاية' });

        await interaction.editReply({ embeds: [timeoutEmbed], components: [] }).catch(() => {});
      }
    });
  }
};
