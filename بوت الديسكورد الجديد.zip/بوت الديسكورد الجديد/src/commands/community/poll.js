const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('إنشاء استطلاع رأي وتصويت تفاعلي في السيرفر (Poll)')
    .addStringOption(opt =>
      opt.setName('question')
        .setDescription('سؤال الاستطلاع')
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('options')
        .setDescription('الخيارات مفصولة بفاصلة (مثال: نعم, لا, ربما)')
        .setRequired(false)),

  async execute(interaction) {
    const question = interaction.options.getString('question');
    const optionsRaw = interaction.options.getString('options');

    const numberEmojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

    let description = '';
    let buttons = [];

    if (optionsRaw) {
      const optionsList = optionsRaw.split(',').map(o => o.trim()).filter(Boolean);
      if (optionsList.length > 5) {
        return interaction.reply({
          content: 'أقصى عدد للخيارات هو 5 يا غالي!',
          ephemeral: true
        });
      }

      description = optionsList.map((opt, i) => `${numberEmojis[i]} **${opt}**`).join('\n\n');

      const row = new ActionRowBuilder();
      optionsList.forEach((opt, i) => {
        row.addComponents(
          new ButtonBuilder()
            .setCustomId(`poll_vote_${i}`)
            .setLabel(`${opt}`)
            .setEmoji(numberEmojis[i])
            .setStyle(ButtonStyle.Primary)
        );
      });
      buttons.push(row);
    } else {
      // Default Yes / No poll
      description = 'اضغط على أحد الأزرار أدناه للتصويت:\n\n👍 **موافق / نعم**\n👎 **معارض / لا**';
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('poll_vote_yes')
          .setLabel('موافق')
          .setEmoji('👍')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('poll_vote_no')
          .setLabel('معارض')
          .setEmoji('👎')
          .setStyle(ButtonStyle.Danger)
      );
      buttons.push(row);
    }

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle(`📊 استطلاع رأي: ${question}`)
      .setDescription(description)
      .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
      .setFooter({ text: 'شارك برأيك وصوتك يهمنا يا باشا!' })
      .setTimestamp();

    await interaction.reply({ content: 'تم إنشاء الاستطلاع بنجاح! 🚀', ephemeral: true });
    await interaction.channel.send({ embeds: [embed], components: buttons });
  }
};
