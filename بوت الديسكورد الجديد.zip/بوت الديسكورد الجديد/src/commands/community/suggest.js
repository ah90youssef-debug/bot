const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const db = require('../../database');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embed');
const config = require('../../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('تقديم اقتراح جديد لتطوير السيرفر (Suggestion)')
    .addStringOption(opt =>
      opt.setName('idea')
        .setDescription('اكتب فكرتك واقتراحك بالتفصيل')
        .setRequired(true)),

  async execute(interaction) {
    const idea = interaction.options.getString('idea');
    const settings = db.getGuild(interaction.guild.id);

    let targetChannel = interaction.channel;
    if (settings.suggestions?.channelId) {
      const customChan = interaction.guild.channels.cache.get(settings.suggestions.channelId);
      if (customChan) targetChannel = customChan;
    }

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setAuthor({ name: `اقتراح من: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
      .setDescription(`💡 **الاقتراح:**\n${idea}`)
      .addFields(
        { name: 'الحالة', value: '🟡 قيد المراجعة والتصويت', inline: true },
        { name: 'صاحب الاقتراح', value: `${interaction.user}`, inline: true }
      )
      .setFooter({ text: 'صوت بـ 👍 للموافقة أو 👎 للمعارضة' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('suggest_up')
        .setLabel('موافق (0)')
        .setEmoji('👍')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('suggest_down')
        .setLabel('معارض (0)')
        .setEmoji('👎')
        .setStyle(ButtonStyle.Danger)
    );

    const msg = await targetChannel.send({ embeds: [embed], components: [row] });

    db.saveSuggestion({
      messageId: msg.id,
      channelId: targetChannel.id,
      guildId: interaction.guild.id,
      authorId: interaction.user.id,
      authorTag: interaction.user.tag,
      content: idea,
      upvotes: [],
      downvotes: [],
      status: 'pending'
    });

    // Try creating a discussion thread
    try {
      await msg.startThread({
        name: `نقاش: ${idea.substring(0, 30)}...`,
        autoArchiveDuration: 1440
      });
    } catch (_) {}

    await interaction.reply({
      content: `تم نشر اقتراحك بنجاح في ${targetChannel}! شكراً لمساهمتك في تطوير السيرفر يا غالي 👑`,
      ephemeral: true
    });
  }
};
