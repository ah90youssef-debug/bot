const { createCanvas, loadImage } = require('@napi-rs/canvas');

async function createWelcomeCard(member) {
  const width = 800;
  const height = 350;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // Background gradient
  const bgGrad = ctx.createLinearGradient(0, 0, width, height);
  bgGrad.addColorStop(0, '#0f172a');
  bgGrad.addColorStop(0.5, '#1e1b4b');
  bgGrad.addColorStop(1, '#0f172a');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Decorative border
  ctx.strokeStyle = '#6366f1';
  ctx.lineWidth = 4;
  ctx.strokeRect(10, 10, width - 20, height - 20);

  // Subtle glowing circle behind avatar
  const avatarCenterX = 150;
  const avatarCenterY = height / 2;
  const avatarRadius = 75;

  const glowGrad = ctx.createRadialGradient(
    avatarCenterX, avatarCenterY, 50,
    avatarCenterX, avatarCenterY, 110
  );
  glowGrad.addColorStop(0, 'rgba(99, 102, 241, 0.6)');
  glowGrad.addColorStop(1, 'rgba(99, 102, 241, 0)');
  ctx.fillStyle = glowGrad;
  ctx.beginPath();
  ctx.arc(avatarCenterX, avatarCenterY, 110, 0, Math.PI * 2);
  ctx.fill();

  // Draw Avatar
  try {
    const avatarUrl = member.user.displayAvatarURL({ extension: 'png', size: 256 });
    const avatarImg = await loadImage(avatarUrl);

    ctx.save();
    ctx.beginPath();
    ctx.arc(avatarCenterX, avatarCenterY, avatarRadius, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(
      avatarImg,
      avatarCenterX - avatarRadius,
      avatarCenterY - avatarRadius,
      avatarRadius * 2,
      avatarRadius * 2
    );
    ctx.restore();

    // Avatar ring
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(avatarCenterX, avatarCenterY, avatarRadius, 0, Math.PI * 2);
    ctx.stroke();
  } catch (err) {
    console.error('Failed to load avatar in welcome card:', err.message);
  }

  // Text Content
  ctx.textAlign = 'left';

  // Subtitle / Greeting
  ctx.fillStyle = '#94a3b8';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText('أهلاً بيك نورتنا يا غالي! 👋', 260, 110);

  // Username
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 36px sans-serif';
  const name = member.user.tag.length > 20 ? member.user.tag.substring(0, 18) + '...' : member.user.tag;
  ctx.fillText(name, 260, 160);

  // Server Name
  ctx.fillStyle = '#a855f7';
  ctx.font = 'bold 24px sans-serif';
  const serverName = member.guild.name.length > 25 ? member.guild.name.substring(0, 23) + '...' : member.guild.name;
  ctx.fillText(`في سيرفر ${serverName}`, 260, 205);

  // Member count pill
  ctx.fillStyle = 'rgba(30, 41, 59, 0.8)';
  ctx.roundRect(260, 235, 280, 45, 12);
  ctx.fill();
  ctx.strokeStyle = '#3b82f6';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = '#38bdf8';
  ctx.font = 'bold 20px sans-serif';
  ctx.fillText(`👥 العضو رقم #${member.guild.memberCount}`, 280, 265);

  return canvas.toBuffer('image/png');
}

module.exports = { createWelcomeCard };
