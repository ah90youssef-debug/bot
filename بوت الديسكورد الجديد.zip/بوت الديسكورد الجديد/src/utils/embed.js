const { EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  createSuccessEmbed: (title, description) => {
    return new EmbedBuilder()
      .setColor(config.successColor || '#57F287')
      .setTitle(`✅ ${title}`)
      .setDescription(description)
      .setFooter({ text: config.footer })
      .setTimestamp();
  },

  createErrorEmbed: (title, description) => {
    return new EmbedBuilder()
      .setColor(config.errorColor || '#ED4245')
      .setTitle(`❌ ${title}`)
      .setDescription(description)
      .setFooter({ text: config.footer })
      .setTimestamp();
  },

  createWarningEmbed: (title, description) => {
    return new EmbedBuilder()
      .setColor(config.warningColor || '#FEE75C')
      .setTitle(`⚠️ ${title}`)
      .setDescription(description)
      .setFooter({ text: config.footer })
      .setTimestamp();
  },

  createInfoEmbed: (title, description) => {
    return new EmbedBuilder()
      .setColor(config.embedColor || '#5865F2')
      .setTitle(`ℹ️ ${title}`)
      .setDescription(description)
      .setFooter({ text: config.footer })
      .setTimestamp();
  }
};
