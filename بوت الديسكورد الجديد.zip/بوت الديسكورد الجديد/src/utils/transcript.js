function generateHtmlTranscript(channel, messages, closedBy, ticketInfo) {
  const sortedMessages = Array.from(messages.values()).reverse();

  const messagesHtml = sortedMessages.map(msg => {
    const avatar = msg.author.displayAvatarURL({ extension: 'png', size: 64 });
    const time = new Date(msg.createdTimestamp).toLocaleString('ar-EG');
    const isBot = msg.author.bot ? '<span class="bot-tag">BOT</span>' : '';

    let content = escapeHtml(msg.content || '');
    content = content.replace(/\n/g, '<br>');

    // Embeds
    let embedsHtml = '';
    if (msg.embeds && msg.embeds.length > 0) {
      embedsHtml = msg.embeds.map(e => `
        <div class="embed-box" style="border-left-color: ${e.hexColor || '#5865F2'}">
          ${e.title ? `<div class="embed-title">${escapeHtml(e.title)}</div>` : ''}
          ${e.description ? `<div class="embed-desc">${escapeHtml(e.description)}</div>` : ''}
        </div>
      `).join('');
    }

    // Attachments
    let attachmentsHtml = '';
    if (msg.attachments && msg.attachments.size > 0) {
      attachmentsHtml = Array.from(msg.attachments.values()).map(att => {
        if (att.contentType && att.contentType.startsWith('image/')) {
          return `<div class="attachment-img"><img src="${att.url}" alt="image" style="max-width: 350px; border-radius: 8px; margin-top: 8px;"></div>`;
        }
        return `<div class="attachment-file"><a href="${att.url}" target="_blank">📎 ${escapeHtml(att.name)}</a></div>`;
      }).join('');
    }

    return `
      <div class="message">
        <img class="avatar" src="${avatar}" alt="Avatar">
        <div class="msg-content">
          <div class="header">
            <span class="username">${escapeHtml(msg.author.tag)}</span>
            ${isBot}
            <span class="time">${time}</span>
          </div>
          <div class="body">${content}</div>
          ${embedsHtml}
          ${attachmentsHtml}
        </div>
      </div>
    `;
  }).join('');

  return `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>سجل تذكرة - ${escapeHtml(channel.name)}</title>
  <style>
    body {
      background-color: #1e1f22;
      color: #dcddde;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 20px;
    }
    .container {
      max-width: 900px;
      margin: auto;
      background: #2b2d31;
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.5);
    }
    .header-box {
      border-bottom: 2px solid #383a40;
      padding-bottom: 15px;
      margin-bottom: 20px;
    }
    .ticket-title {
      font-size: 24px;
      font-weight: bold;
      color: #5865F2;
    }
    .ticket-meta {
      font-size: 14px;
      color: #949ba4;
      margin-top: 5px;
    }
    .message {
      display: flex;
      gap: 15px;
      margin-bottom: 18px;
      padding: 8px;
      border-radius: 8px;
      transition: background 0.2s;
    }
    .message:hover {
      background: #313338;
    }
    .avatar {
      width: 44px;
      height: 44px;
      border-radius: 50%;
    }
    .msg-content {
      flex: 1;
    }
    .header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 4px;
    }
    .username {
      font-weight: bold;
      color: #f2f3f5;
    }
    .bot-tag {
      background: #5865f2;
      color: white;
      font-size: 10px;
      font-weight: bold;
      padding: 1px 4px;
      border-radius: 4px;
    }
    .time {
      font-size: 12px;
      color: #949ba4;
    }
    .body {
      font-size: 15px;
      line-height: 1.4;
      color: #dbdee1;
      word-break: break-word;
    }
    .embed-box {
      border-left: 4px solid #5865f2;
      background: #1e1f22;
      padding: 10px 14px;
      border-radius: 4px;
      margin-top: 8px;
    }
    .embed-title {
      font-weight: bold;
      color: white;
      margin-bottom: 4px;
    }
    .embed-desc {
      font-size: 14px;
      color: #b5bac1;
    }
    .attachment-file a {
      color: #00a8fc;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header-box">
      <div class="ticket-title">📑 سجل محادثة: ${escapeHtml(channel.name)}</div>
      <div class="ticket-meta">
        السيرفر: ${escapeHtml(channel.guild.name)} |
        صاحب التذكرة: ${escapeHtml(ticketInfo?.creatorTag || 'غير معروف')} |
        أغلقت بواسطة: ${escapeHtml(closedBy?.tag || 'الإدارة')} |
        التاريخ: ${new Date().toLocaleString('ar-EG')}
      </div>
    </div>
    <div class="messages">
      ${messagesHtml}
    </div>
  </div>
</body>
</html>
  `;
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

module.exports = { generateHtmlTranscript };
