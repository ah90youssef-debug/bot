const fs = require('fs');
const path = require('path');

const logFile = path.join(__dirname, '..', '..', 'bot.log');

function formatTime() {
  return new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
}

module.exports = {
  info: (msg, ...args) => {
    const text = `[INFO] [${formatTime()}] ${msg}`;
    console.log('\x1b[36m%s\x1b[0m', text, ...args);
    fs.appendFileSync(logFile, `${text} ${args.join(' ')}\n`, 'utf8');
  },
  success: (msg, ...args) => {
    const text = `[SUCCESS] [${formatTime()}] ${msg}`;
    console.log('\x1b[32m%s\x1b[0m', text, ...args);
    fs.appendFileSync(logFile, `${text} ${args.join(' ')}\n`, 'utf8');
  },
  warn: (msg, ...args) => {
    const text = `[WARN] [${formatTime()}] ${msg}`;
    console.log('\x1b[33m%s\x1b[0m', text, ...args);
    fs.appendFileSync(logFile, `${text} ${args.join(' ')}\n`, 'utf8');
  },
  error: (msg, ...args) => {
    const text = `[ERROR] [${formatTime()}] ${msg}`;
    console.error('\x1b[31m%s\x1b[0m', text, ...args);
    fs.appendFileSync(logFile, `${text} ${args.join(' ')}\n`, 'utf8');
  }
};
