// Anti-Nuke and Anti-Raid in-memory tracking
class SecurityManager {
  constructor() {
    this.joins = new Map(); // guildId -> array of timestamps
    this.channelDeletes = new Map(); // `${guildId}_${userId}` -> array of timestamps
    this.roleDeletes = new Map(); // `${guildId}_${userId}` -> array of timestamps
    this.bans = new Map(); // `${guildId}_${userId}` -> array of timestamps
  }

  // Track member join and return true if raid detected
  registerJoin(guildId, maxIn10Sec = 5) {
    const now = Date.now();
    const timestamps = this.joins.get(guildId) || [];
    const recent = timestamps.filter(t => now - t < 10000);
    recent.push(now);
    this.joins.set(guildId, recent);
    return recent.length >= maxIn10Sec;
  }

  // Track channel deletion by an executor
  registerChannelDelete(guildId, userId, maxPerMin = 3) {
    const now = Date.now();
    const key = `${guildId}_${userId}`;
    const timestamps = this.channelDeletes.get(key) || [];
    const recent = timestamps.filter(t => now - t < 60000);
    recent.push(now);
    this.channelDeletes.set(key, recent);
    return recent.length >= maxPerMin;
  }

  // Track role deletion by an executor
  registerRoleDelete(guildId, userId, maxPerMin = 3) {
    const now = Date.now();
    const key = `${guildId}_${userId}`;
    const timestamps = this.roleDeletes.get(key) || [];
    const recent = timestamps.filter(t => now - t < 60000);
    recent.push(now);
    this.roleDeletes.set(key, recent);
    return recent.length >= maxPerMin;
  }

  // Track ban by an executor
  registerBan(guildId, userId, maxPerMin = 3) {
    const now = Date.now();
    const key = `${guildId}_${userId}`;
    const timestamps = this.bans.get(key) || [];
    const recent = timestamps.filter(t => now - t < 60000);
    recent.push(now);
    this.bans.set(key, recent);
    return recent.length >= maxPerMin;
  }
}

module.exports = new SecurityManager();
