const { Events, EmbedBuilder } = require('discord.js');
const db = require('../database');
const config = require('../../config.json');
const logger = require('../utils/logger');

function getXpNeeded(level) {
  return 5 * (level * level) + 50 * level + 100;
}

module.exports = {
  name: Events.MessageCreate,
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    const guildId = message.guild.id;
    const userId = message.author.id;
    const settings = db.getGuild(guildId);

    // LEVELS & XP SYSTEM
    if (settings.levels && settings.levels.enabled) {
      const userData = db.getUser(guildId, userId);
      const now = Date.now();
      const cooldownMs = (settings.levels.cooldownSeconds || 60) * 1000;

      if (now - (userData.lastXpAt || 0) >= cooldownMs) {
        const minXp = settings.levels.xpMin || 15;
        const maxXp = settings.levels.xpMax || 25;
        const gainedXp = Math.floor(Math.random() * (maxXp - minXp + 1)) + minXp;

        userData.xp += gainedXp;
        userData.lastXpAt = now;

        let needed = getXpNeeded(userData.level);
        let leveledUp = false;

        while (userData.xp >= needed) {
          userData.xp -= needed;
          userData.level += 1;
          needed = getXpNeeded(userData.level);
          leveledUp = true;
        }

        db.updateUser(guildId, userId, userData);

        if (leveledUp) {
          // Send Level Up notification
          const msgTemplate = settings.levels.message || 'مبروك يا {user}! وصلت للمستوى **{level}** وعملت شغل عالي يا فنان! 🔥';
          const notification = msgTemplate
            .replace(/{user}/g, message.author.toString())
            .replace(/{level}/g, userData.level.toString());

          const targetChannel = settings.levels.channelId
            ? message.guild.channels.cache.get(settings.levels.channelId) || message.channel
            : message.channel;

          const embed = new EmbedBuilder()
            .setColor(config.successColor)
            .setTitle('🎉 ترقية مستوى جديدة (Level Up)!')
            .setDescription(notification)
            .setThumbnail(message.author.displayAvatarURL())
            .setFooter({ text: `استمر في التفاعل للوصول لمستويات أعلى!` })
            .setTimestamp();

          targetChannel.send({ embeds: [embed] }).catch(() => {});

          // Role Rewards Check
          if (settings.levels.roleRewards && settings.levels.roleRewards.length > 0) {
            const reward = settings.levels.roleRewards.find(r => r.level === userData.level);
            if (reward && reward.roleId) {
              const role = message.guild.roles.cache.get(reward.roleId);
              if (role && message.member.manageable) {
                message.member.roles.add(role).catch(() => {});
                targetChannel.send({
                  content: `🎖️ وحصلت على رتبة جديدة مكافأة لتفاعلك: **${role.name}**! تستاهل كل خير يا باشا!`
                }).catch(() => {});
              }
            }
          }
        }
      }
    }
  }
};
