const { Events, AttachmentBuilder, EmbedBuilder } = require('discord.js');
const db = require('../database');
const { createWelcomeCard } = require('../utils/canvas');
const security = require('../utils/security');
const { createWarningEmbed, createInfoEmbed } = require('../utils/embed');
const logger = require('../utils/logger');
const config = require('../../config.json');

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member, client) {
    const guild = member.guild;
    const settings = db.getGuild(guild.id);

    // 1. ANTI-RAID DETECTION
    if (settings.antiRaid && settings.antiRaid.enabled) {
      const isRaid = security.registerJoin(guild.id, settings.antiRaid.maxJoinsIn10Sec || 5);
      if (isRaid) {
        logger.warn(`[Anti-Raid] Raid detected in guild: ${guild.name}`);

        if (settings.antiRaid.alertChannelId) {
          const alertChan = guild.channels.cache.get(settings.antiRaid.alertChannelId);
          if (alertChan) {
            alertChan.send({
              embeds: [createWarningEmbed(
                '🚨 تحذير أمني: هجوم دخول جماعي (Anti-Raid)!',
                `تم رصد دخول عدد كبير من الحسابات في ثوانٍ معدودة!\n` +
                `> **العضو الأخير:** ${member.user.tag} (<@${member.id}>)\n` +
                `> **تاريخ إنشاء الحساب:** <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>\n` +
                `> **الإجراء المتخذ:** تم تفعيل وضع الحظر المؤقت للتصدي للهجوم.`
              )]
            });
          }
        }

        // Action: kick suspicious raid account
        if (settings.antiRaid.action === 'kick' && member.kickable) {
          await member.kick('Anti-Raid System Protection').catch(() => {});
          return;
        }
      }
    }

    // 2. AUTO-ROLE ASSIGNMENT
    if (settings.welcome && settings.welcome.autoRoleId) {
      try {
        const role = guild.roles.cache.get(settings.welcome.autoRoleId);
        if (role && guild.members.me.permissions.has('ManageRoles') && role.position < guild.members.me.roles.highest.position) {
          await member.roles.add(role);
        }
      } catch (err) {
        logger.error(`Failed to assign auto-role to ${member.user.tag}:`, err.message);
      }
    }

    // 3. WELCOME MESSAGE & CARD
    if (settings.welcome && settings.welcome.enabled && settings.welcome.channelId) {
      const welcomeChannel = guild.channels.cache.get(settings.welcome.channelId);
      if (welcomeChannel) {
        const welcomeText = (settings.welcome.message || 'منور يا {user} في سيرفر **{server}**! 🎉 أنت العضو رقم **#{count}**')
          .replace(/{user}/g, member.toString())
          .replace(/{server}/g, guild.name)
          .replace(/{count}/g, guild.memberCount.toString());

        try {
          if (settings.welcome.imageEnabled !== false) {
            const cardBuffer = await createWelcomeCard(member);
            const attachment = new AttachmentBuilder(cardBuffer, { name: 'welcome-card.png' });

            const embed = new EmbedBuilder()
              .setColor(config.embedColor)
              .setDescription(welcomeText)
              .setImage('attachment://welcome-card.png')
              .setFooter({ text: `السيرفر نور بوجودك يا غالي 👑 | #${guild.memberCount}` })
              .setTimestamp();

            await welcomeChannel.send({ embeds: [embed], files: [attachment] });
          } else {
            await welcomeChannel.send({ content: welcomeText });
          }
        } catch (err) {
          logger.error('Error sending welcome message:', err.message);
          welcomeChannel.send({ content: welcomeText }).catch(() => {});
        }
      }
    }

    // 4. AUDIT LOG (Member Join)
    if (settings.logs && settings.logs.enabled && settings.logs.channelId && settings.logs.events.memberJoin) {
      const logChannel = guild.channels.cache.get(settings.logs.channelId);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setColor('#57F287')
          .setTitle('📥 عضو جديد انضم للسيرفر')
          .setThumbnail(member.user.displayAvatarURL())
          .addFields(
            { name: 'العضو', value: `${member.user.tag} (${member})`, inline: true },
            { name: 'الآيدي', value: `\`${member.id}\``, inline: true },
            { name: 'عمر الحساب', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }
          )
          .setFooter({ text: `إجمالي الأعضاء: ${guild.memberCount}` })
          .setTimestamp();

        logChannel.send({ embeds: [logEmbed] }).catch(() => {});
      }
    }
  }
};
