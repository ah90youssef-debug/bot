const { Events, EmbedBuilder } = require('discord.js');
const db = require('../database');

module.exports = {
  name: Events.MessageUpdate,
  async execute(oldMessage, newMessage, client) {
    if (!oldMessage.guild || oldMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return; // Ignore pin/embed updates

    const settings = db.getGuild(oldMessage.guild.id);
    if (!settings.logs?.enabled || !settings.logs?.channelId || !settings.logs?.events?.messageUpdate) return;

    const logChannel = oldMessage.guild.channels.cache.get(settings.logs.channelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('✏️ تم تعديل رسالة')
      .addFields(
        { name: 'صاحب الرسالة', value: `${oldMessage.author?.tag} (<@${oldMessage.author?.id}>)`, inline: true },
        { name: 'الروم', value: `${oldMessage.channel}`, inline: true },
        { name: 'قبل التعديل', value: oldMessage.content ? `\`\`\`${oldMessage.content.substring(0, 900)}\`\`\`` : '*فارغ*' },
        { name: 'بعد التعديل', value: newMessage.content ? `\`\`\`${newMessage.content.substring(0, 900)}\`\`\`` : '*فارغ*' }
      )
      .setFooter({ text: `ID: ${oldMessage.id}` })
      .setTimestamp();

    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
