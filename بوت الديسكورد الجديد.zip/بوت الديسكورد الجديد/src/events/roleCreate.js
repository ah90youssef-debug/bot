const { Events, EmbedBuilder } = require('discord.js');
const db = require('../database');

module.exports = {
  name: Events.RoleCreate,
  async execute(role, client) {
    const guild = role.guild;
    const settings = db.getGuild(guild.id);

    if (!settings.logs?.enabled || !settings.logs?.channelId || !settings.logs?.events?.roleCreate) return;

    const logChannel = guild.channels.cache.get(settings.logs.channelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor('#57F287')
      .setTitle('🛡️ تم إنشاء رتبة جديدة')
      .addFields(
        { name: 'الرتبة', value: `${role} (\`${role.name}\`)`, inline: true },
        { name: 'اللون', value: `${role.hexColor}`, inline: true }
      )
      .setFooter({ text: `ID: ${role.id}` })
      .setTimestamp();

    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
