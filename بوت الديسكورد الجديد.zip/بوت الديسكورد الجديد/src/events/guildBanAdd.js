const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const db = require('../database');
const security = require('../utils/security');
const { createWarningEmbed } = require('../utils/embed');
const logger = require('../utils/logger');

module.exports = {
  name: Events.GuildBanAdd,
  async execute(ban, client) {
    const guild = ban.guild;
    const settings = db.getGuild(guild.id);

    try {
      const fetchedLogs = await guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.MemberBanAdd
      }).catch(() => null);

      const banLog = fetchedLogs?.entries.first();
      const executor = banLog?.executor;

      // 1. ANTI-MASS BAN CHECK
      if (executor && executor.id !== client.user.id && executor.id !== guild.ownerId) {
        const whitelist = settings.antiNuke?.whitelist || [];
        if (!whitelist.includes(executor.id)) {
          const maxBans = settings.antiNuke?.maxBansPerMin || 3;
          const isBreach = security.registerBan(guild.id, executor.id, maxBans);

          if (isBreach && settings.antiNuke?.enabled) {
            logger.warn(`[Anti-Nuke] Mass ban limit exceeded by ${executor.tag} in ${guild.name}`);

            const member = await guild.members.fetch(executor.id).catch(() => null);
            if (member && member.manageable) {
              const dangerousRoles = member.roles.cache.filter(r =>
                r.id !== guild.id &&
                (r.permissions.has('Administrator') || r.permissions.has('BanMembers'))
              );
              if (dangerousRoles.size > 0) {
                await member.roles.remove(dangerousRoles, 'Anti-Nuke Protection: Mass ban triggered');
              }
            }

            if (settings.antiNuke.alertChannelId) {
              const alertChan = guild.channels.cache.get(settings.antiNuke.alertChannelId);
              if (alertChan) {
                alertChan.send({
                  embeds: [createWarningEmbed(
                    '🚨 إنذار أمني خطير: حظر جماعي (Mass-Ban Anti-Nuke)!',
                    `تم رصد قيام العضو **${executor.tag}** (<@${executor.id}>) بحظر أعضاء بمعدل مريب!\n` +
                    `> **الإجراء المتخذ:** تم سحب صلاحية الحظر والرتب فوراً.\n` +
                    `> **العضو المحظور:** ${ban.user.tag}`
                  )]
                });
              }
            }
          }
        }
      }

      // 2. AUDIT LOG
      if (settings.logs?.enabled && settings.logs?.channelId && settings.logs?.events?.modActions) {
        const logChannel = guild.channels.cache.get(settings.logs.channelId);
        if (logChannel) {
          const embed = new EmbedBuilder()
            .setColor('#ED4245')
            .setTitle('🔨 تم حظر عضو')
            .addFields(
              { name: 'العضو المحظور', value: `${ban.user.tag} (<@${ban.user.id}>)`, inline: true },
              { name: 'بواسطة', value: executor ? `${executor.tag} (<@${executor.id}>)` : 'غير معروف', inline: true },
              { name: 'السبب', value: ban.reason || 'بدون سبب محدد', inline: false }
            )
            .setFooter({ text: `ID: ${ban.user.id}` })
            .setTimestamp();

          logChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }

    } catch (err) {
      logger.error('Error handling guildBanAdd event:', err.message);
    }
  }
};
