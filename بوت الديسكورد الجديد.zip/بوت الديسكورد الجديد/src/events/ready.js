const { Events, ActivityType } = require('discord.js');
const logger = require('../utils/logger');
const db = require('../database');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    logger.success(`🚀 البوت اشتغل بنجاح وسجل دخوله باسم: ${client.user.tag}`);
    logger.info(`السيرفرات المتصلة: ${client.guilds.cache.size} سيرفر | إجمالي الأعضاء: ${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0)} عضو`);

    // Set Bot Activity
    client.user.setPresence({
      activities: [
        {
          name: 'سيد المعلمين | /help 👑',
          type: ActivityType.Custom,
          state: 'حامي السيرفر وفي خدمتك يا باشا! 🛡️'
        }
      ],
      status: 'online'
    });

    // Server Stats Voice Channels Auto-Updater (every 10 minutes)
    setInterval(async () => {
      try {
        for (const guild of client.guilds.cache.values()) {
          const settings = db.getGuild(guild.id);
          if (settings.serverStats && settings.serverStats.enabled) {
            // Update Members channel
            if (settings.serverStats.membersChannelId) {
              const chan = guild.channels.cache.get(settings.serverStats.membersChannelId);
              if (chan) {
                const totalMembers = guild.memberCount;
                await chan.setName(`👥 الأعضاء: ${totalMembers.toLocaleString()}`).catch(() => {});
              }
            }
            // Update Bots channel
            if (settings.serverStats.botsChannelId) {
              const chan = guild.channels.cache.get(settings.serverStats.botsChannelId);
              if (chan) {
                const botsCount = guild.members.cache.filter(m => m.user.bot).size;
                await chan.setName(`🤖 البوتات: ${botsCount}`).catch(() => {});
              }
            }
            // Update Channels channel
            if (settings.serverStats.channelsChannelId) {
              const chan = guild.channels.cache.get(settings.serverStats.channelsChannelId);
              if (chan) {
                const totalChannels = guild.channels.cache.size;
                await chan.setName(`📁 الرومات: ${totalChannels}`).catch(() => {});
              }
            }
          }
        }
      } catch (e) {
        logger.error('Error updating server stats channels:', e.message);
      }
    }, 10 * 60 * 1000);
  }
};
