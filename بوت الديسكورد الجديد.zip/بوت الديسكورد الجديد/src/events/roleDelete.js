const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const db = require('../database');
const security = require('../utils/security');
const { createWarningEmbed } = require('../utils/embed');
const logger = require('../utils/logger');

module.exports = {
  name: Events.RoleDelete,
  async execute(role, client) {
    const guild = role.guild;
    const settings = db.getGuild(guild.id);

    try {
      const fetchedLogs = await guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.RoleDelete
      }).catch(() => null);

      const deletionLog = fetchedLogs?.entries.first();
      const executor = deletionLog?.executor;

      // 1. ANTI-NUKE CHECK
      if (executor && executor.id !== client.user.id && executor.id !== guild.ownerId) {
        const whitelist = settings.antiNuke?.whitelist || [];
        if (!whitelist.includes(executor.id)) {
          const maxDeletes = settings.antiNuke?.maxRoleDeletesPerMin || 3;
          const isBreach = security.registerRoleDelete(guild.id, executor.id, maxDeletes);

          if (isBreach && settings.antiNuke?.enabled) {
            logger.warn(`[Anti-Nuke] Role deletion limit exceeded by ${executor.tag} in ${guild.name}`);

            const member = await guild.members.fetch(executor.id).catch(() => null);
            if (member && member.manageable) {
              const dangerousRoles = member.roles.cache.filter(r =>
                r.id !== guild.id &&
                (r.permissions.has('Administrator') || r.permissions.has('ManageRoles'))
              );
              if (dangerousRoles.size > 0) {
                await member.roles.remove(dangerousRoles, 'Anti-Nuke Protection: Mass role deletion triggered');
              }
            }

            if (settings.antiNuke.alertChannelId) {
              const alertChan = guild.channels.cache.get(settings.antiNuke.alertChannelId);
              if (alertChan) {
                alertChan.send({
                  embeds: [createWarningEmbed(
                    '🚨 إنذار أمني خطير: حذف رتب جماعي (Anti-Nuke)!',
                    `تم رصد قيام العضو **${executor.tag}** (<@${executor.id}>) بحذف رتب بشكل متكرر ومريب!\n` +
                    `> **الإجراء المتخذ:** تم سحب صلاحيات الإدارة والرتب لحماية السيرفر فوراً.\n` +
                    `> **الرتبة المحذوفة:** ${role.name}`
                  )]
                });
              }
            }
          }
        }
      }

      // 2. AUDIT LOG
      if (settings.logs?.enabled && settings.logs?.channelId && settings.logs?.events?.roleDelete) {
        const logChannel = guild.channels.cache.get(settings.logs.channelId);
        if (logChannel) {
          const embed = new EmbedBuilder()
            .setColor('#ED4245')
            .setTitle('🛡️ تم حذف رتبة')
            .addFields(
              { name: 'اسم الرتبة', value: `${role.name}`, inline: true },
              { name: 'بواسطة', value: executor ? `${executor.tag} (<@${executor.id}>)` : 'غير معروف', inline: true }
            )
            .setFooter({ text: `ID: ${role.id}` })
            .setTimestamp();

          logChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }

    } catch (err) {
      logger.error('Error handling roleDelete event:', err.message);
    }
  }
};
