const { Events } = require('discord.js');
const buttonHandler = require('../handlers/buttonHandler');
const { createErrorEmbed } = require('../utils/embed');
const logger = require('../utils/logger');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, client) {
    // 1. SLASH COMMANDS
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) {
        logger.warn(`No command matching ${interaction.commandName} was found.`);
        return;
      }

      // Cooldown check
      const { cooldowns } = client;
      if (!cooldowns.has(command.data.name)) {
        cooldowns.set(command.data.name, new Map());
      }

      const now = Date.now();
      const timestamps = cooldowns.get(command.data.name);
      const defaultCooldownDuration = 3; // 3 seconds
      const cooldownAmount = (command.cooldown ?? defaultCooldownDuration) * 1000;

      if (timestamps.has(interaction.user.id)) {
        const expirationTime = timestamps.get(interaction.user.id) + cooldownAmount;
        if (now < expirationTime) {
          const expiredTimestamp = Math.round(expirationTime / 1000);
          return interaction.reply({
            content: `صبرك شوية يا باشا! الأمر ده في فترة انتظار، تقدر تستخدمه <t:${expiredTimestamp}:R>. ⏳`,
            ephemeral: true
          });
        }
      }

      timestamps.set(interaction.user.id, now);
      setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);

      try {
        await command.execute(interaction, client);
      } catch (error) {
        logger.error(`Error executing /${interaction.commandName}:`, error);
        const replyObj = {
          embeds: [createErrorEmbed('خطأ في تنفيذ الأمر', 'حصل خطأ غير متوقع أثناء تنفيذ الأمر يا فنان، تواصل مع الإدارة.')],
          ephemeral: true
        };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(replyObj).catch(() => {});
        } else {
          await interaction.reply(replyObj).catch(() => {});
        }
      }
    }

    // 2. BUTTONS & SELECT MENUS
    else if (interaction.isButton() || interaction.isStringSelectMenu()) {
      try {
        await buttonHandler(interaction, client);
      } catch (error) {
        logger.error('Error handling button/select interaction:', error);
      }
    }
  }
};
