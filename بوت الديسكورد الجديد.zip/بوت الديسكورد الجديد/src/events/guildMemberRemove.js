const { Events, EmbedBuilder } = require('discord.js');
const db = require('../database');
const logger = require('../utils/logger');

module.exports = {
  name: Events.GuildMemberRemove,
  async execute(member, client) {
    const guild = member.guild;
    const settings = db.getGuild(guild.id);

    // 1. LEAVE MESSAGE
    if (settings.leave && settings.leave.enabled && settings.leave.channelId) {
      const leaveChannel = guild.channels.cache.get(settings.leave.channelId);
      if (leaveChannel) {
        const leaveText = (settings.leave.message || 'مع السلامة يا {user}.. هنشتاقلك في {server} والله 💔')
          .replace(/{user}/g, member.user.tag)
          .replace(/{server}/g, guild.name);

        const embed = new EmbedBuilder()
          .setColor('#ED4245')
          .setDescription(leaveText)
          .setThumbnail(member.user.displayAvatarURL())
          .setFooter({ text: `عدد الأعضاء المتبقي: ${guild.memberCount}` })
          .setTimestamp();

        leaveChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    // 2. AUDIT LOG (Member Leave)
    if (settings.logs && settings.logs.enabled && settings.logs.channelId && settings.logs.events.memberLeave) {
      const logChannel = guild.channels.cache.get(settings.logs.channelId);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setColor('#ED4245')
          .setTitle('📤 عضو غادر السيرفر')
          .setThumbnail(member.user.displayAvatarURL())
          .addFields(
            { name: 'العضو', value: `${member.user.tag} (<@${member.id}>)`, inline: true },
            { name: 'الآيدي', value: `\`${member.id}\``, inline: true },
            { name: 'الرتب السابقة', value: member.roles.cache.filter(r => r.id !== guild.id).map(r => r.name).join(', ') || 'بدون رتب', inline: false }
          )
          .setFooter({ text: `إجمالي الأعضاء: ${guild.memberCount}` })
          .setTimestamp();

        logChannel.send({ embeds: [logEmbed] }).catch(() => {});
      }
    }
  }
};
