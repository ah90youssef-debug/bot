const { Events, EmbedBuilder, AuditLogEvent } = require('discord.js');
const db = require('../database');
const security = require('../utils/security');
const { createWarningEmbed } = require('../utils/embed');
const logger = require('../utils/logger');

module.exports = {
  name: Events.ChannelDelete,
  async execute(channel, client) {
    if (!channel.guild) return;
    const guild = channel.guild;
    const settings = db.getGuild(guild.id);

    try {
      // Fetch who deleted the channel via audit logs
      const fetchedLogs = await guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.ChannelDelete
      }).catch(() => null);

      const deletionLog = fetchedLogs?.entries.first();
      const executor = deletionLog?.executor;

      // 1. ANTI-NUKE CHECK
      if (executor && executor.id !== client.user.id && executor.id !== guild.ownerId) {
        const whitelist = settings.antiNuke?.whitelist || [];
        if (!whitelist.includes(executor.id)) {
          const maxDeletes = settings.antiNuke?.maxChannelDeletesPerMin || 3;
          const isBreach = security.registerChannelDelete(guild.id, executor.id, maxDeletes);

          if (isBreach && settings.antiNuke?.enabled) {
            logger.warn(`[Anti-Nuke] Channel deletion limit exceeded by ${executor.tag} in ${guild.name}`);

            // Take action: revoke roles of the malicious executor or quarantine
            const member = await guild.members.fetch(executor.id).catch(() => null);
            if (member && member.manageable) {
              const dangerousRoles = member.roles.cache.filter(r =>
                r.id !== guild.id &&
                (r.permissions.has('Administrator') || r.permissions.has('ManageChannels'))
              );
              if (dangerousRoles.size > 0) {
                await member.roles.remove(dangerousRoles, 'Anti-Nuke Protection: Mass channel deletion triggered');
              }
            }

            // Alert security channel
            if (settings.antiNuke.alertChannelId) {
              const alertChan = guild.channels.cache.get(settings.antiNuke.alertChannelId);
              if (alertChan) {
                alertChan.send({
                  embeds: [createWarningEmbed(
                    '🚨 إنذار أمني خطير: محاولة تخريب (Anti-Nuke)!',
                    `تم رصد قيام العضو **${executor.tag}** (<@${executor.id}>) بحذف رومات بشكل متكرر وسريع!\n` +
                    `> **الإجراء المتخذ:** تم سحب رتب الإدارة منه فوراً لحماية السيرفر.\n` +
                    `> **الروم المحذوف:** ${channel.name}`
                  )]
                });
              }
            }
          }
        }
      }

      // 2. AUDIT LOG
      if (settings.logs?.enabled && settings.logs?.channelId && settings.logs?.events?.channelDelete) {
        const logChannel = guild.channels.cache.get(settings.logs.channelId);
        if (logChannel) {
          const embed = new EmbedBuilder()
            .setColor('#ED4245')
            .setTitle('📁 تم حذف روم')
            .addFields(
              { name: 'اسم الروم', value: `${channel.name}`, inline: true },
              { name: 'نوع الروم', value: `${channel.type}`, inline: true },
              { name: 'بواسطة', value: executor ? `${executor.tag} (<@${executor.id}>)` : 'غير معروف', inline: true }
            )
            .setFooter({ text: `ID: ${channel.id}` })
            .setTimestamp();

          logChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }

    } catch (err) {
      logger.error('Error handling channelDelete event:', err.message);
    }
  }
};
