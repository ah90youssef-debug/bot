const { Events, EmbedBuilder } = require('discord.js');
const db = require('../database');

module.exports = {
  name: Events.GuildMemberUpdate,
  async execute(oldMember, newMember, client) {
    const guild = newMember.guild;
    const settings = db.getGuild(guild.id);

    if (!settings.logs?.enabled || !settings.logs?.channelId || !settings.logs?.events?.memberRoleUpdate) return;

    const logChannel = guild.channels.cache.get(settings.logs.channelId);
    if (!logChannel) return;

    // Check added roles
    const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
    // Check removed roles
    const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));

    if (addedRoles.size > 0 || removedRoles.size > 0) {
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('👤 تحديث رتب العضو')
        .setThumbnail(newMember.user.displayAvatarURL())
        .addFields({
          name: 'العضو',
          value: `${newMember.user.tag} (<@${newMember.id}>)`,
          inline: false
        })
        .setFooter({ text: `ID: ${newMember.id}` })
        .setTimestamp();

      if (addedRoles.size > 0) {
        embed.addFields({
          name: '➕ رتب تمت إضافتها',
          value: addedRoles.map(r => `${r}`).join(', ')
        });
      }

      if (removedRoles.size > 0) {
        embed.addFields({
          name: '➖ رتب تمت إزالتها',
          value: removedRoles.map(r => `${r}`).join(', ')
        });
      }

      logChannel.send({ embeds: [embed] }).catch(() => {});
    }
  }
};
