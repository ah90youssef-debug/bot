const { Events, EmbedBuilder } = require('discord.js');
const db = require('../database');

module.exports = {
  name: Events.ChannelCreate,
  async execute(channel, client) {
    if (!channel.guild) return;
    const guild = channel.guild;
    const settings = db.getGuild(guild.id);

    if (!settings.logs?.enabled || !settings.logs?.channelId || !settings.logs?.events?.channelCreate) return;

    const logChannel = guild.channels.cache.get(settings.logs.channelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor('#57F287')
      .setTitle('📁 تم إنشاء روم جديد')
      .addFields(
        { name: 'الروم', value: `${channel} (\`${channel.name}\`)`, inline: true },
        { name: 'القسم', value: channel.parent ? `${channel.parent.name}` : 'بدون قسم', inline: true }
      )
      .setFooter({ text: `ID: ${channel.id}` })
      .setTimestamp();

    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
