const { Events, EmbedBuilder } = require('discord.js');
const db = require('../database');

module.exports = {
  name: Events.MessageDelete,
  async execute(message, client) {
    if (!message.guild || message.author?.bot) return;

    const settings = db.getGuild(message.guild.id);
    if (!settings.logs?.enabled || !settings.logs?.channelId || !settings.logs?.events?.messageDelete) return;

    const logChannel = message.guild.channels.cache.get(settings.logs.channelId);
    if (!logChannel) return;

    const embed = new EmbedBuilder()
      .setColor('#ED4245')
      .setTitle('🗑️ تم حذف رسالة')
      .addFields(
        { name: 'صاحب الرسالة', value: `${message.author?.tag || 'مجهول'} (<@${message.author?.id}>)`, inline: true },
        { name: 'الروم', value: `${message.channel}`, inline: true },
        { name: 'محتوى الرسالة', value: message.content ? `\`\`\`${message.content.substring(0, 1000)}\`\`\`` : '*لا يوجد نص (ربما صورة أو ملف فقط)*' }
      )
      .setFooter({ text: `ID: ${message.id}` })
      .setTimestamp();

    if (message.attachments.size > 0) {
      embed.addFields({
        name: 'مرفقات الرسالة',
        value: message.attachments.map(a => a.name).join(', ')
      });
    }

    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
