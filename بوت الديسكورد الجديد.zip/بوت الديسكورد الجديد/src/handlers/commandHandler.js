const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

module.exports = (client) => {
  client.commands = new Map();
  client.slashCommands = [];

  const commandsPath = path.join(__dirname, '..', 'commands');
  const commandFolders = fs.readdirSync(commandsPath);

  for (const folder of commandFolders) {
    const folderPath = path.join(commandsPath, folder);
    if (!fs.statSync(folderPath).isDirectory()) continue;

    const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
      const filePath = path.join(folderPath, file);
      try {
        const command = require(filePath);
        if (command && command.data) {
          client.commands.set(command.data.name, command);
          client.slashCommands.push(command.data.toJSON());
        }
      } catch (err) {
        logger.error(`Error loading command ${file}:`, err.message);
      }
    }
  }

  logger.info(`Loaded ${client.commands.size} slash commands.`);
};
