const {
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder
} = require('discord.js');
const db = require('../database');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed } = require('../utils/embed');
const { generateHtmlTranscript } = require('../utils/transcript');
const logger = require('../utils/logger');

module.exports = async (interaction, client) => {
  const { customId, guild, member, user } = interaction;
  const settings = db.getGuild(guild.id);

  // 1. TICKET CREATION
  if (customId === 'ticket_select' || customId.startsWith('ticket_create_')) {
    let categoryKey = 'other';
    if (customId === 'ticket_select') {
      categoryKey = interaction.values[0];
    } else {
      categoryKey = customId.replace('ticket_create_', '');
    }

    const catObj = settings.tickets.categories.find(c => c.id === categoryKey) || { label: 'تذكرة عامة', emoji: '🎫' };

    // Check if user already has open ticket of this type
    const existing = db.getTickets(guild.id).find(t => t.creatorId === user.id && t.status === 'open');
    if (existing) {
      const channel = guild.channels.cache.get(existing.channelId);
      if (channel) {
        return interaction.reply({
          content: `يا غالي، أنت بالفعل فاتح تذكرة في الروم ${channel}! برجاء المتابعة هناك.`,
          ephemeral: true
        });
      }
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      const ticketNumber = ++settings.tickets.counter;
      db.updateGuild(guild.id, g => { g.tickets.counter = ticketNumber; });

      // Permission overwrites
      const permissionOverwrites = [
        {
          id: guild.id,
          deny: [PermissionFlagsBits.ViewChannel]
        },
        {
          id: user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles
          ]
        },
        {
          id: client.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ManageChannels,
            PermissionFlagsBits.EmbedLinks,
            PermissionFlagsBits.AttachFiles
          ]
        }
      ];

      // Add staff roles permissions
      if (settings.tickets.supportRoleIds && settings.tickets.supportRoleIds.length > 0) {
        for (const roleId of settings.tickets.supportRoleIds) {
          if (guild.roles.cache.has(roleId)) {
            permissionOverwrites.push({
              id: roleId,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory,
                PermissionFlagsBits.AttachFiles
              ]
            });
          }
        }
      }

      // Create Channel
      const ticketChannel = await guild.channels.create({
        name: `ticket-${ticketNumber}`,
        type: ChannelType.GuildText,
        parent: settings.tickets.categoryId || null,
        permissionOverwrites
      });

      // Save ticket in DB
      db.saveTicket({
        id: `ticket_${ticketNumber}`,
        channelId: ticketChannel.id,
        guildId: guild.id,
        creatorId: user.id,
        creatorTag: user.tag,
        type: catObj.label,
        status: 'open',
        createdAt: Date.now()
      });

      // Ticket welcome message
      const ticketEmbed = createInfoEmbed(
        `تذكرة جديدة: ${catObj.emoji} ${catObj.label}`,
        `أهلاً بيك يا **${user}** في تذكرتك الخاصة!\n\n` +
        `> **نوع المشكلة:** ${catObj.label}\n` +
        `> **صاحب التذكرة:** <@${user.id}>\n` +
        `> **الحالة:** 🟢 مفتوحة وجاري انتظار فريق الدعم.\n\n` +
        `من فضلك اشرح استفسارك بالتفصيل وسيقوم أحد المسؤولين بالرد عليك في أقرب وقت يا باشا.`
      );

      const actionRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_close')
          .setLabel('إغلاق التذكرة')
          .setEmoji('🔒')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('ticket_claim')
          .setLabel('استلام التذكرة')
          .setEmoji('🙋‍♂️')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('ticket_transcript')
          .setLabel('تصدير السجل')
          .setEmoji('📑')
          .setStyle(ButtonStyle.Secondary)
      );

      await ticketChannel.send({
        content: `${user} | ${settings.tickets.supportRoleIds.map(r => `<@&${r}>`).join(' ') || ''}`,
        embeds: [ticketEmbed],
        components: [actionRow]
      });

      await interaction.editReply({
        content: `تم فتح تذكرتك بنجاح يا غالي! توجه إلى ${ticketChannel} للمتابعة. 🚀`
      });

    } catch (err) {
      logger.error('Failed to create ticket channel:', err);
      await interaction.editReply({
        content: 'حصل خطأ أثناء محاولة فتح التذكرة، تأكد من صلاحيات البوت يا ريس!'
      });
    }
  }

  // 2. TICKET CLOSE
  else if (customId === 'ticket_close') {
    const ticket = db.getTicketByChannel(interaction.channel.id);
    await interaction.reply({
      content: 'جاري إغلاق التذكرة وحفظ سجل المحادثة (Transcript)... سيتم حذف الروم خلال 5 ثوانٍ.',
      ephemeral: false
    });

    try {
      // Fetch messages for transcript
      const messages = await interaction.channel.messages.fetch({ limit: 100 });
      const html = generateHtmlTranscript(interaction.channel, messages, user, ticket);
      const buffer = Buffer.from(html, 'utf-8');
      const attachment = new AttachmentBuilder(buffer, { name: `transcript-${interaction.channel.name}.html` });

      // Send to log channel
      if (settings.tickets.logChannelId) {
        const logChannel = guild.channels.cache.get(settings.tickets.logChannelId);
        if (logChannel) {
          const logEmbed = createInfoEmbed(
            `📑 تم إغلاق تذكرة: ${interaction.channel.name}`,
            `> **أغلقت بواسطة:** ${user} (${user.tag})\n` +
            `> **صاحب التذكرة:** ${ticket?.creatorTag || 'غير معروف'}\n` +
            `> **النوع:** ${ticket?.type || 'عامة'}\n` +
            `> **الرسائل المحفوظة:** ${messages.size} رسالة\n\n` +
            `مرفق ملف الـ HTML الكامل للمحادثة.`
          );
          await logChannel.send({ embeds: [logEmbed], files: [attachment] });
        }
      }

      // Try DM transcript to creator
      if (ticket?.creatorId) {
        try {
          const creator = await client.users.fetch(ticket.creatorId);
          if (creator) {
            await creator.send({
              content: `تم إغلاق تذكرتك في **${guild.name}** يا غالي. إليك نسخة كاملة من سجل المحادثة:`,
              files: [attachment]
            });
          }
        } catch (_) {}
      }

      if (ticket) {
        db.saveTicket({
          ...ticket,
          status: 'closed',
          closedBy: user.id,
          closedAt: Date.now()
        });
      }

      setTimeout(async () => {
        try {
          await interaction.channel.delete();
        } catch (e) {
          logger.error('Failed to delete ticket channel:', e.message);
        }
      }, 5000);

    } catch (err) {
      logger.error('Error closing ticket:', err);
    }
  }

  // 3. TICKET CLAIM
  else if (customId === 'ticket_claim') {
    const isStaff = member.permissions.has(PermissionFlagsBits.ManageMessages) ||
      (settings.tickets.supportRoleIds && settings.tickets.supportRoleIds.some(r => member.roles.cache.has(r)));

    if (!isStaff) {
      return interaction.reply({
        content: 'يا باشا أنت مش من طاقم الدعم عشان تستلم التذكرة دي!',
        ephemeral: true
      });
    }

    const embed = createSuccessEmbed(
      'تم استلام التذكرة',
      `تم استلام هذه التذكرة بواسطة **${user}** (${user.tag}). هو المسؤول عن متابعتك يا غالي!`
    );
    await interaction.reply({ embeds: [embed] });
  }

  // 4. TICKET TRANSCRIPT (MANUAL)
  else if (customId === 'ticket_transcript') {
    await interaction.deferReply({ ephemeral: true });
    try {
      const ticket = db.getTicketByChannel(interaction.channel.id);
      const messages = await interaction.channel.messages.fetch({ limit: 100 });
      const html = generateHtmlTranscript(interaction.channel, messages, user, ticket);
      const buffer = Buffer.from(html, 'utf-8');
      const attachment = new AttachmentBuilder(buffer, { name: `transcript-${interaction.channel.name}.html` });

      await interaction.editReply({
        content: 'تفضل يا باشا، ملف السجل الكامل للمحادثة جاهز للتحميل:',
        files: [attachment]
      });
    } catch (err) {
      await interaction.editReply({ content: 'حصل خطأ أثناء استخراج السجل.' });
    }
  }

  // 5. GIVEAWAY JOIN / LEAVE
  else if (customId === 'giveaway_join') {
    const giveaway = db.getGiveaway(interaction.message.id);
    if (!giveaway || giveaway.ended) {
      return interaction.reply({
        content: 'للأسف القيف أواي ده انتهى خلاص يا غالي!',
        ephemeral: true
      });
    }

    const userId = user.id;
    let joined = false;
    if (giveaway.participants.includes(userId)) {
      giveaway.participants = giveaway.participants.filter(id => id !== userId);
      joined = false;
    } else {
      giveaway.participants.push(userId);
      joined = true;
    }

    db.saveGiveaway(giveaway);

    // Update message button count or text
    await interaction.reply({
      content: joined
        ? `🎉 تم تسجيل دخولك بنجاح في القيف اواي يا بطل! عدد المشاركين الحالي: **${giveaway.participants.length}**`
        : `👋 خرجت من المشاركة في القيف اواي. نتمنى لك التوفيق في المرات الجاية!`,
      ephemeral: true
    });
  }

  // 6. SUGGESTIONS VOTING
  else if (customId === 'suggest_up' || customId === 'suggest_down') {
    const suggestion = db.getSuggestion(interaction.message.id);
    if (!suggestion) {
      return interaction.reply({
        content: 'الاقتراح ده مش متسجل في السيستم.',
        ephemeral: true
      });
    }

    const userId = user.id;
    if (customId === 'suggest_up') {
      suggestion.downvotes = suggestion.downvotes.filter(id => id !== userId);
      if (suggestion.upvotes.includes(userId)) {
        suggestion.upvotes = suggestion.upvotes.filter(id => id !== userId);
      } else {
        suggestion.upvotes.push(userId);
      }
    } else {
      suggestion.upvotes = suggestion.upvotes.filter(id => id !== userId);
      if (suggestion.downvotes.includes(userId)) {
        suggestion.downvotes = suggestion.downvotes.filter(id => id !== userId);
      } else {
        suggestion.downvotes.push(userId);
      }
    }

    db.saveSuggestion(suggestion);

    // Update the message components with new counts
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('suggest_up')
        .setLabel(`موافق (${suggestion.upvotes.length})`)
        .setEmoji('👍')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('suggest_down')
        .setLabel(`معارض (${suggestion.downvotes.length})`)
        .setEmoji('👎')
        .setStyle(ButtonStyle.Danger)
    );

    await interaction.update({ components: [row] });
  }
};
